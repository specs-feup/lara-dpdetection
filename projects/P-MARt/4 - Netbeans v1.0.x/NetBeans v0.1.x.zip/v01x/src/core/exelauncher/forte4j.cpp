/*
 *                 Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License
 * Version 1.0 (the "License"). You may not use this file except in
 * compliance with the License. A copy of the License is available at
 * http://www.sun.com/
 * 
 * The Original Code is Forte for Java, Community Edition. The Initial
 * Developer of the Original Code is Sun Microsystems, Inc. Portions
 * Copyright 1997-2000 Sun Microsystems, Inc. All Rights Reserved.
 */

/* $Id: forte4j.cpp,v 1.10.2.2 2000/04/27 09:07:33 ttran Exp $ */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include <process.h>
#include <commdlg.h>

#include <jni.h>

#include "resource.h"

#define PROG_FULLNAME "Forte for Java"
#define IDE_MAIN_CLASS "org/netbeans/Main"
#define UPDATER_MAIN_CLASS "org/netbeans/updater/UpdaterFrame"

#define DEFAULT_ARGS "-J-Xmx96m"

#define JDK_KEY "Software\\JavaSoft\\Java Development Kit"
#define FORTE_KEY "Software\\Sun Microsystems, Inc.\\Forte for Java\\1.0"
#define FORTE_USERDIR_VALUE_NAME "UserDir"

#define RUN_IDE "-run_ide"
#define RUN_UPDATER "-run_updater"

static char jdkhome[MAX_PATH];
static char fortehome[MAX_PATH];
static char userdir[MAX_PATH];

static int hotspot = -1;
static int multiuser = 0;
static int runide = 0;
static int runupdater = 0;

static JavaVM *jvm;

static char classpath[1024 * 16];
static char classpathBefore[1024 * 16];
static char classpathAfter[1024 * 16];

static JavaVMOption *options;
static int numOptions, maxOptions;

static char *progArgv[1024];
static int progArgc = 0;

static void runClass(char *mainclass, int argc, char *argv[]);

static void fatal(const char *str);
static int findJdkFromRegistry(const char* keyname, char jdkhome[]);

static void addJdkJarsToClassPath(const char *jdkhome);
static void addForteJarsToClassPath(const char *fortehome);

static void addToClassPath(const char *pathprefix, const char *path);
static void addAllFilesToClassPath(const char *dir, const char *pattern);

static void parseForteCfg(char *fortehome);
static void parseCommandLine(char *argstr);
static void parseArgs(int argc, char *argv[]);
void addOption(char *str, void *info);

static int getUserDir(char* dir);
static int setupUserDirIfNeeded(char *fortehome, char *userdir);
static void normalizeUserDir(char *userdir);
static char* getStringRes(int id);

#ifndef WINMAIN

int main(int argc, char *argv[]) {
  char exepath[MAX_PATH];
  char buf[MAX_PATH], *pc;
  
  GetModuleFileName(0, buf, sizeof buf);
  strcpy(exepath, buf);

  pc = strrchr(buf, '\\');
  if (pc != NULL) {             // always holds
    strlwr(pc + 1);
    if (strstr(pc + 1, "_multiuser") != NULL)
      multiuser = 1;
    *pc = '\0';	// remove .exe filename
  }

  // remove \bin
  pc = strrchr(buf, '\\');
  if (pc != NULL && 0 == stricmp("\\bin", pc))
    *pc = '\0';
  strcpy(fortehome, buf);

  findJdkFromRegistry(JDK_KEY, jdkhome);
  parseCommandLine(DEFAULT_ARGS);
  parseForteCfg(fortehome);
  parseArgs(argc - 1, argv + 1); // skip progname

  if (!runide && !runupdater) {
    char **newargv = (char**) malloc(argc+10);
    int i, rc;

    if (multiuser) {
      if (userdir[0] == '\0') {
        if (!getUserDir(userdir))
          exit(1);
      }
      if (setupUserDirIfNeeded(fortehome, userdir))
        fatal(getStringRes(MSG_CANNOT_SETUP_USERDIR));
    }
        
    sprintf(buf, "\"%s\"", argv[0]);
    newargv[0] = strdup(buf);
    
    for (i = 1; i < argc; i++) {
      sprintf(buf, "\"%s\"", argv[i]);
      newargv[i+1] = strdup(buf);
    }
    i++;

    if (userdir[0] != '\0') {
      newargv[i++] = "-userdir";

      strcat(strcat(strcpy(buf, "\""), userdir), "\"");
      newargv[i++] = strdup(buf);
    }
    newargv[i] = NULL;

  AGAIN:

    // run IDE first
    
    newargv[1] = RUN_IDE;
    rc = _spawnv(_P_WAIT, exepath, newargv);

    if (rc == 66) {
      newargv[1] = RUN_UPDATER;
      rc = _spawnv(_P_WAIT, exepath, newargv);
      goto AGAIN;
    }
  } else if (runide) {
    argc -= 2;
    argv += 2;
    runClass(IDE_MAIN_CLASS, argc, argv);
  } else if (runupdater) {
    argc -= 2;
    argv += 2;
    runClass(UPDATER_MAIN_CLASS, argc, argv);
  }

  return 0;
}
#endif

void runClass(char *mainclass, int argc, char *argv[]) {
  char buf[1024], *pc;

  //XXX  parseArgs(argc, argv);

  if (jdkhome[0] == '\0')
    fatal(getStringRes(MSG_CANNOT_FIND_JDK));

  strcat(strcat(strcpy(buf, "-Djava.security.policy="), fortehome),
         "\\bin\\forte4j.policy");
  addOption(strdup(buf), NULL);
  
  strcat(strcpy(buf, "-Dnetbeans.home="), fortehome);
  addOption(strdup(buf), NULL);

  if (userdir[0] != '\0') {
    strcat(strcpy(buf, "-Dnetbeans.user="), userdir);
    addOption(strdup(buf), NULL);
  }
  
  if (classpathBefore[0] != '\0')
    strcpy(classpath, classpathBefore);
  else
    classpath[0] = '\0';
  
  if (userdir[0] != '\0')
    addForteJarsToClassPath(userdir);

  addForteJarsToClassPath(fortehome);
  addJdkJarsToClassPath(jdkhome);

  if (classpathAfter[0] != '\0') {
    if (classpath[strlen(classpath)] != ';')
      strcat(classpath, ";");
    strcat(classpath, classpathAfter);
  }
  
  pc = getenv("CLASSPATH");
  if (pc != NULL) {
    if (classpath[strlen(classpath)] != ';') {
      strcat(classpath, ";");
      strcat(classpath, pc);
    }
  }
      
  char* cp_prop = (char*) malloc(strlen(classpath) + 60);
  strcat(strcpy(cp_prop, "-Djava.class.path="), classpath);
  addOption(cp_prop, NULL);

  //
  //  Loading JVM
  //

  char jvmpath[MAX_PATH];
  HINSTANCE hJvm = NULL;
  
  if (hotspot == 1 || hotspot == -1) {
    strcat(strcpy(jvmpath, jdkhome), "\\jre\\bin\\hotspot\\jvm.dll");
    hJvm = LoadLibrary(jvmpath);
  }
  
  if (NULL == hJvm && hotspot != 1) {
    strcat(strcpy(jvmpath, jdkhome), "\\jre\\bin\\classic\\jvm.dll");
    hJvm = LoadLibrary(jvmpath);
  }

  if (NULL == hJvm) {
    sprintf(buf, getStringRes(MSG_CANNOT_LOAD_JVM), jvmpath);
    fatal(buf);
  }
  
  JavaVMInitArgs vm_args;
  JNIEnv *env;
  jint rc;
  void (*func)();

  memset(&vm_args, 0, sizeof(vm_args));
  vm_args.version  = JNI_VERSION_1_2;

  vm_args.nOptions = numOptions;
  vm_args.options  = options;
  vm_args.ignoreUnrecognized = JNI_TRUE;
  
  func = (void(*)())::GetProcAddress(hJvm, "JNI_CreateJavaVM");
  if (NULL == func)
    fatal(getStringRes(MSG_CANNOT_FIND_JNI_CreateJavaVM));

  
  rc = ((jint (JNICALL *)
         (JavaVM **, void **env, void *args)) func)(&jvm, (void**) &env, &vm_args);
  if (rc < 0)
    fatal(getStringRes(MSG_CANNOT_CREATE_JVM));

  jclass cls;
  jmethodID mid;
    
  // create the Java VM

  cls = env->FindClass(mainclass);
  if (cls == 0) {
    char buf[2048];
    sprintf(buf, getStringRes(MSG_CANNOT_FIND_CLASS), mainclass);
    fatal(buf);
  }
 
  mid = env->GetStaticMethodID(cls, "main", "([Ljava/lang/String;)V");
  if (mid == 0) {
    sprintf(buf, getStringRes(MSG_CANNOT_FIND_METHOD_MAIN), mainclass);
    fatal(buf);
  }

  // prog args

  jstring jstr;
  jobjectArray args;
  int i;
  
  args = env->NewObjectArray(progArgc, env->FindClass("java/lang/String"), NULL);
  if (args == 0)
    fatal(getStringRes(MSG_OUT_OF_MEM));

  for (i = 0; i < progArgc; i++) {
    jstr = env->NewStringUTF(progArgv[i]);
    if (jstr == 0)
      fatal(getStringRes(MSG_OUT_OF_MEM));
    env->SetObjectArrayElement(args, i, jstr);
  }

  // call main()
    
  env->CallStaticVoidMethod(cls, mid, args);
  if (env->ExceptionOccurred()) {
    env->ExceptionDescribe();
  }

  // Wait until we are the only user thread remaining then unload VM

  jvm->DestroyJavaVM();
  ::FreeLibrary(hJvm);
}

//////////

/*
 * Returns string data for the specified registry value name, or
 * NULL if not found.
 */
static char * GetStringValue(HKEY key, const char *name)
{
  DWORD type, size;
  char *value = 0;

  if (RegQueryValueEx(key, name, 0, &type, 0, &size) == 0 && type == REG_SZ) {
    value = (char*) malloc(size);
    if (RegQueryValueEx(key, name, 0, 0, (unsigned char*)value, &size) != 0) {
      free(value);
      value = 0;
    }
  }
  return value;
}

static int findJdkFromRegistry(const char* keyname, char jdkhome[])
{
  HKEY hkey = NULL, subkey = NULL;
  char *ver = NULL;
  int rc = 1;
  
  if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, keyname, 0, KEY_READ, &hkey) == 0) {
    ver = GetStringValue(hkey, "CurrentVersion");
    if (ver == NULL)
      goto quit;

    if (RegOpenKeyEx(hkey, ver, 0, KEY_READ, &subkey) == 0) {
      char *home = GetStringValue(subkey, "JavaHome");
      if (home == NULL)
        goto quit;
      strcpy(jdkhome, home);
      free(home);
      rc = 0;
    }
  }

 quit:
  if (ver != NULL)
    free(ver);
  if (subkey != NULL)
    RegCloseKey(subkey);
  if (hkey != NULL)
    RegCloseKey(hkey);
  return rc;
}

void addToClassPath(const char *pathprefix, const char *path) {
  char buf[1024];
    
  strcpy(buf, pathprefix);
  if (path != NULL)
    strcat(strcat(buf, "\\"), path);

  if (classpath[0] != '\0')
    strcat(classpath, ";");
  strcat(classpath, buf);
}
  
void addJdkJarsToClassPath(const char *jdkhome)
{
  addToClassPath(jdkhome, "lib\\dt.jar");
  addToClassPath(jdkhome, "lib\\tools.jar");
}

void addForteJarsToClassPath(const char *fortehome)
{
  char buf[1024];

  strcat(strcpy(buf, fortehome), "\\lib\\patches");
  addAllFilesToClassPath(buf, "*.jar");
  addAllFilesToClassPath(buf, "*.zip");
  
  addToClassPath(fortehome, "lib");

  strcat(strcpy(buf, fortehome), "\\lib");
  addAllFilesToClassPath(buf, "*.jar");
    
  /*
    addToClassPath(classpath, fortehome, "lib\\developer.jar");
    addToClassPath(classpath, fortehome, "lib\\openide.jar");
  */

  strcat(strcpy(buf, fortehome), "\\lib\\ext");
  addAllFilesToClassPath(buf, "*.jar");
  addAllFilesToClassPath(buf, "*.zip");
}

void addAllFilesToClassPath(const char *dir,
                            const char *pattern) {
  char buf[1024];
  struct _finddata_t fileinfo;
  long hFile;

  strcat(strcat(strcpy(buf, dir), "\\"), pattern);
  
  if ((hFile = _findfirst(buf, &fileinfo)) != -1L) {
    addToClassPath(dir, fileinfo.name);

    while (0 == _findnext(hFile, &fileinfo))
      addToClassPath(dir, fileinfo.name);
    
    _findclose(hFile);
  }
}

void fatal(const char *str)
{
//#ifdef WINMAIN
  ::MessageBox(NULL, str, PROG_FULLNAME, MB_ICONSTOP | MB_OK);
//#else  
//  fprintf(stderr, "%s\n", str);
//#endif
  exit(255);
}

/*
 * Adds a new VM option with the given given name and value.
 */
void addOption(char *str, void *info)
{
  /*
   * Expand options array if needed to accomodate at least one more
   * VM option.
   */
  if (numOptions >= maxOptions) {
    if (options == 0) {
      maxOptions = 4;
      options = (JavaVMOption*) malloc(maxOptions * sizeof(JavaVMOption));
    } else {
      JavaVMOption *tmp;
      maxOptions *= 2;
      tmp = (JavaVMOption*)malloc(maxOptions * sizeof(JavaVMOption));
      memcpy(tmp, options, numOptions * sizeof(JavaVMOption));
      free(options);
      options = tmp;
    }
  }
  options[numOptions].optionString = str;
  options[numOptions++].extraInfo = info;
}

void parseArgs(int argc, char *argv[]) {
  char *arg;

  while (argc > 0 && (arg = *argv) != 0) {
    argv++;
    argc--;

    if (strcmp("-h", arg) == 0 || strcmp("-help", arg) == 0) {
      fatal(getStringRes(MSG_USAGE));
    } else if (strcmp("-hotspot", arg) == 0)
      hotspot = 1;
    else if (strcmp("-classic", arg) == 0)
      hotspot = 0;
    else if (0 == strcmp("-multi", arg)) {
      multiuser = 1;
    } else if (0 == strcmp("-userdir", arg)) {
      multiuser = 1;
      if (argc > 0) {
        arg = *argv;
        argv++;
        argc--;
        if (arg != 0) {
          strcpy(userdir, arg);
          normalizeUserDir(userdir);
        }
      }
    } else if (0 == strcmp(RUN_IDE, arg)) {
      runide = 1;
      runupdater = 0;
    } else if (0 == strcmp(RUN_UPDATER, arg)) {
      runide = 0;
      runupdater = 1;
    } else if (0 == strcmp("-jdkhome", arg)) {
      if (argc > 0) {
        arg = *argv;
        argv++;
        argc--;
        if (arg != 0) {
          strcpy(jdkhome, arg);
        }
      }
    } else if (0 == strcmp("-cp:p", arg)) {
      if (argc > 0) {
        arg = *argv;
        argv++;
        argc--;
        if (arg != 0) {
          if (classpathBefore[0] != '\0'
              && classpathBefore[strlen(classpathBefore)] != ';')
            strcat(classpathBefore, ";");
          strcat(classpathBefore, arg);
        }
      }
    } else if (0 == strcmp("-cp", arg) || 0 == strcmp("-cp:a", arg)) {
      if (argc > 0) {
        arg = *argv;
        argv++;
        argc--;
        if (arg != 0) {
          if (classpathAfter[0] != '\0'
              && classpathAfter[strlen(classpathAfter)] != ';')
            strcat(classpathAfter, ";");
          strcat(classpathAfter, arg);
        }
      }
    } else if (0 == strncmp("-J", arg, 2)) {
      arg += 2;
      if (strcmp("-hotspot", arg) == 0)
        hotspot = 1;
      else if (strcmp("-classic", arg) == 0)
        hotspot = 0;
      else if (strcmp(arg, "-verbosegc") == 0) {
        addOption("-verbose:gc", NULL);
      } else if (strcmp(arg, "-t") == 0) {
        addOption("-Xt", NULL);
      } else if (strcmp(arg, "-tm") == 0) {
        addOption("-Xtm", NULL);
      } else if (strcmp(arg, "-debug") == 0) {
        addOption("-Xdebug", NULL);
      } else if (strcmp(arg, "-noclassgc") == 0) {
        addOption("-Xnoclassgc", NULL);
      } else if (strcmp(arg, "-Xfuture") == 0) {
        addOption("-Xverify:all", NULL);
      } else if (strcmp(arg, "-verify") == 0) {
        addOption("-Xverify:all", NULL);
      } else if (strcmp(arg, "-verifyremote") == 0) {
        addOption("-Xverify:remote", NULL);
      } else if (strcmp(arg, "-noverify") == 0) {
        addOption("-Xverify:none", NULL);
      } else if (strncmp(arg, "-prof", 5) == 0) {
        const char *p = arg + 5;
        char *tmp = (char*) malloc(strlen(arg) + 50);
        if (*p) {
          sprintf(tmp, "-Xrunhprof:cpu=old,file=%s", p + 1);
        } else {
          sprintf(tmp, "-Xrunhprof:cpu=old,file=java.prof");
        }
        addOption(tmp, NULL);
      } else if (strncmp(arg, "-ss", 3) == 0 ||
                 strncmp(arg, "-oss", 4) == 0 ||
                 strncmp(arg, "-ms", 3) == 0 ||
                 strncmp(arg, "-mx", 3) == 0) {
        char *tmp = (char*) malloc(strlen(arg) + 6);
        sprintf(tmp, "-X%s", arg + 1); /* skip '-' */
        addOption(tmp, NULL);
      } else {
        addOption(arg, NULL);
      }
    } else {
      progArgv[progArgc++] = arg;
    }
  }
}

static void parseForteCfg(char *fortehome) {
  char cfgpath[MAX_PATH];
  strcat(strcpy(cfgpath, fortehome), "\\bin\\forte4j.cfg");

  int fh;
  char buf[64 * 1024];
  unsigned bytesread;
    
  if ((fh = _open(cfgpath, _O_RDONLY)) != -1) {
    if ((bytesread = _read(fh, buf, sizeof(buf) - 1)) > 0) {
      buf[bytesread] = '\0';
      parseCommandLine(strdup(buf));
    }
    _close( fh );
  }
}

void parseCommandLine(char *argstr) {
  char **argv = (char**) malloc(2048 * sizeof (char*));
  int argc = 0;

#define START 0
#define NORMAL 1
#define IN_QUOTES 2
#define IN_APOS 3

  char *p, *q;
  int state = NORMAL;
  char token[1024 * 64];
  int eof;
  
  q = argstr;
  p = token;
  state = START;
  eof = 0;
  
  while (!eof) {
    if (*q == '\0')
      eof = 1;
    
    switch (state) {
    case START:
      if (*q == ' ' || *q == '\r' || *q == '\n' || *q == '\t') {
        q++;
        continue;
      }

      p = token;
      *p = '\0';
      
      if (*q == '"') {
        state = IN_QUOTES;
        q++;
        continue;
      }
      if (*q == '\'') {
        state = IN_APOS;
        q++;
        continue;
      }
      
      state = NORMAL;
      continue;

    case NORMAL:
      if (*q == ' ' || *q == '\r' || *q == '\n' || *q == '\t' || *q == '\0') {
        *p = '\0';
        argv[argc] = strdup(token);
        argc++;
        state = START;
      } else {
        *p++ = *q++;
      }
      break;

    case IN_QUOTES:
      if (*q == '"') {
        if (*(q+1) == '"') {
          *p++ = '"';
          q += 2;
        } else {
          *p = '\0';
          
          argv[argc] = strdup(token);
          argc++;

          q++;
          state = START;
        }
      } else if (*q == '\0') {
          *p = '\0';
          argv[argc] = strdup(token);
          argc++;
          state = START;
      } else {
        *p++ = *q++;
      }
      break;
      
    case IN_APOS:
      if (*q == '\'') {
        if (*(q+1) == '\'') {
          *p++ = '\'';
          q += 2;
        } else {
          *p = '\0';
          
          argv[argc] = strdup(token);
          argc++;

          q++;
          state = START;
        }
      } else if (*q == '\0') {
          *p = '\0';
          argv[argc] = strdup(token);
          argc++;
          state = START;
      } else {
        *p++ = *q++;
      }
      break;
    }
  }
  
  parseArgs(argc, argv);
}

//
//
//

char* getStringRes(int id)
{
  static char buffer[1024 * 4];

  buffer[0]=0;
  LoadString (GetModuleHandle (NULL), id, buffer, sizeof buffer);
  return buffer;
}

static LRESULT CALLBACK UserDirDlgProc(HWND hDlg, UINT message,
                                       WPARAM wParam, LPARAM lParam);
static BOOL CenterWindow (HWND hwndChild, HWND hwndParent);
static int copyTree(char *dst, char *src);

static int buttonPressed = -1;
static char userdirBuf[MAX_PATH];

static int getUserDir(char* dir) {
  HKEY hkey = NULL;

  if (RegOpenKeyEx(HKEY_CURRENT_USER, FORTE_KEY, 0, KEY_READ, &hkey) == 0) {
      char *val = GetStringValue(hkey, FORTE_USERDIR_VALUE_NAME);
      if (val != NULL)
        strcpy(dir, val);
      RegCloseKey(hkey);
      if (val != NULL)
        return 1;
  }
  
  DialogBox(GetModuleHandle(NULL),
            MAKEINTRESOURCE(USERDIR_DLG), NULL, (DLGPROC)UserDirDlgProc);
  if (buttonPressed != IDOK)
    return 0;
  strcpy(dir, userdirBuf);

  if (ERROR_SUCCESS == RegCreateKeyEx(HKEY_CURRENT_USER,
                                      FORTE_KEY,
                                      0,
                                      NULL,
                                      REG_OPTION_NON_VOLATILE,
                                      KEY_WRITE,
                                      NULL,
                                      &hkey,
                                      NULL)) {
    RegSetValueEx(hkey,
                  FORTE_USERDIR_VALUE_NAME,
                  0,
                  REG_SZ,
                  (CONST BYTE*) dir,
                  strlen(dir) + 1);
    RegCloseKey(hkey);
  }
  
  return 1;
}


LRESULT CALLBACK UserDirDlgProc(HWND hDlg, UINT message,
                                   WPARAM wParam, LPARAM lParam)
{
  char buf[MAX_PATH];
  char *pc, *qc;

  switch (message) {
  case WM_INITDIALOG:
    CenterWindow (hDlg, GetDesktopWindow());
    return (TRUE);
     
  case WM_COMMAND:
    switch (LOWORD(wParam)) {
    case IDOK:
      buf[0] = '\0';
      GetDlgItemText(hDlg, IDC_USERDIR, buf, sizeof buf);

      pc = buf;
      while (*pc == ' '  || *pc == '\t' || *pc == '\r' || *pc == '\n')
        pc++;

      qc = pc + strlen(pc) - 1;
      while (qc >= pc && (*pc == ' '  || *pc == '\t'
                          || *pc == '\r' || *pc == '\n'))
        qc--;
      
      if( qc >= pc)
        *(qc+1) = '\0';

      if (*pc == '\0') {
        ::MessageBox(NULL, getStringRes(MSG_MUST_ENTER_DIRECTORY),
                     PROG_FULLNAME, MB_ICONSTOP | MB_OK);
        return (TRUE);
      }

      strcpy(userdirBuf, pc);
      normalizeUserDir(userdirBuf);
      
      if (setupUserDirIfNeeded(fortehome, userdirBuf)) {
        ::MessageBox(NULL, getStringRes(MSG_CANNOT_SETUP_USERDIR),
                     PROG_FULLNAME, MB_ICONSTOP | MB_OK);
        return (TRUE);
      }

      EndDialog(hDlg, TRUE);
      buttonPressed = IDOK;
      return (TRUE);
       
    case IDCANCEL:
      EndDialog(hDlg, TRUE);
      buttonPressed = IDCANCEL;
      return (TRUE);
       
    case IDC_BROWSE:
      break;
    }
    return (TRUE);
  }
   
  return FALSE;
}

BOOL CenterWindow (HWND hwndChild, HWND hwndParent)
{
   RECT    rChild, rParent, rWorkArea;
   int     wChild, hChild, wParent, hParent;
   int     xNew, yNew;
   BOOL  bResult;

   // Get the Height and Width of the child window
   GetWindowRect (hwndChild, &rChild);
   wChild = rChild.right - rChild.left;
   hChild = rChild.bottom - rChild.top;

   // Get the Height and Width of the parent window
   GetWindowRect (hwndParent, &rParent);
   wParent = rParent.right - rParent.left;
   hParent = rParent.bottom - rParent.top;

   // Get the limits of the 'workarea'
   bResult = SystemParametersInfo(
      SPI_GETWORKAREA,  // system parameter to query or set
      sizeof(RECT),
      &rWorkArea,
      0);
   if (!bResult) {
      rWorkArea.left = rWorkArea.top = 0;
      rWorkArea.right = GetSystemMetrics(SM_CXSCREEN);
      rWorkArea.bottom = GetSystemMetrics(SM_CYSCREEN);
   }

   // Calculate new X position, then adjust for workarea
   xNew = rParent.left + ((wParent - wChild) /2);
   if (xNew < rWorkArea.left) {
      xNew = rWorkArea.left;
   } else if ((xNew+wChild) > rWorkArea.right) {
      xNew = rWorkArea.right - wChild;
   }

   // Calculate new Y position, then adjust for workarea
   yNew = rParent.top  + ((hParent - hChild) /2);
   if (yNew < rWorkArea.top) {
      yNew = rWorkArea.top;
   } else if ((yNew+hChild) > rWorkArea.bottom) {
      yNew = rWorkArea.bottom - hChild;
   }

   // Set it, and return
   return SetWindowPos (hwndChild, NULL, xNew, yNew, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
}

void normalizeUserDir(char *userdir) {
  char buf[MAX_PATH], *pc;

  strcpy(buf, userdir);
  userdir[0] = '\0';

  if (buf[0] == '\\' && buf[1] == '\\') { // UNC share
    userdir[0] = '\\';
    userdir[1] = '\\';
    userdir[2] = '\0';
    pc = strtok(buf + 2, "/\\");
  } else {
    pc = strtok(buf, "/\\");
  }
  
  while (pc != NULL) {
    if (*pc != '\0') {
      if (userdir[0] != '\0' && userdir[strlen(userdir) - 1] != '\\')
        strcat(userdir, "\\");
      strcat(userdir, pc);
    }
    pc = strtok(NULL,  "/\\");
  }
  if (userdir[1] == ':' && userdir[2] == '\0')
    strcat(userdir, "\\");
}

int setupUserDirIfNeeded(char *fortehome, char *userdir) {
  int rc = 0;
  char buf[MAX_PATH], buf2[MAX_PATH], *pc;
  WIN32_FIND_DATA ffd;
  HANDLE ffh, fh;
  
  HCURSOR wait = LoadCursor(NULL, IDC_WAIT);
  HCURSOR normal = LoadCursor(NULL, IDC_ARROW);

  SetCursor(wait);

  // First test if userdir has already been set up

  strcat(strcpy(buf, userdir), "\\system");
  memset(&ffd, 0, sizeof ffd);
  ffd.dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
  ffh = FindFirstFile(buf, &ffd);
  if (ffh != INVALID_HANDLE_VALUE) {
    FindClose(ffh);
    goto quit;
  }

  // Need to setup

  buf2[0] = '\0';
  strcpy(buf, userdir);
  
  if (buf[0] == '\\' && buf[1] == '\\') {
    // skip top level share
    buf2[1] = buf2[0] = '\\';
    buf2[2] = '\0';

    pc = strtok(buf + 2, "\\");
    if (pc != NULL) {
      strcat(buf2, pc);
      pc = strtok(NULL, "\\");
      if (pc != NULL) {
        strcat(strcat(buf2, "\\"), pc);
        pc = strtok(NULL, "\\");
      }
    }
  }  else if (buf[1] == ':') {
    // skip drive's root dir
    
    buf2[0] = buf[0];
    buf2[1] = ':';
    buf2[2] = '\0';
    pc = strtok(buf+2, "/\\");
  } else {
    pc = strtok(buf, "/\\");
  }

  for (; pc != NULL; pc = strtok(NULL,  "/\\")) {
    if (*pc != '\0') {
      if (buf2[0] != '\0')
        strcat(buf2, "\\");
      strcat(buf2, pc);

      memset(&ffd, 0, sizeof ffd);
      ffd.dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
      ffh = FindFirstFile(buf2, &ffd);
      if (ffh != INVALID_HANDLE_VALUE) {
        FindClose(ffh);
      }
      if (ffh == INVALID_HANDLE_VALUE) {
        if (!CreateDirectory(buf2, NULL)) {
          rc = 1;
          goto quit;
        }
      }
    }
  }

  strcat(strcpy(buf, userdir), "\\system");  
  if (!CreateDirectory(buf, NULL)) {
    rc = 1;
    goto quit;
  }

  strcat(strcpy(buf, userdir), "\\system\\project.last_hidden");
  fh = CreateFile(buf, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
                  FILE_ATTRIBUTE_NORMAL, NULL);
  if (fh != INVALID_HANDLE_VALUE)
    CloseHandle(fh);

  strcat(strcpy(buf, userdir), "\\system\\project.basic_hidden");
  fh = CreateFile(buf, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
                  FILE_ATTRIBUTE_NORMAL, NULL);
  if (fh != INVALID_HANDLE_VALUE)
    CloseHandle(fh);
  
  strcat(strcpy(buf, userdir), "\\system\\Projects");  
  if (!CreateDirectory(buf, NULL)) {
    rc = 1;
    goto quit;
  }
  strcat(strcpy(buf, userdir), "\\system\\Projects\\workspace.ser_hidden");
  fh = CreateFile(buf, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
                  FILE_ATTRIBUTE_NORMAL, NULL);
  if (fh != INVALID_HANDLE_VALUE)
    CloseHandle(fh);
  
  strcat(strcpy(buf, userdir), "\\modules");  
  CreateDirectory(buf, NULL);

  strcat(strcpy(buf, userdir), "\\lib");  
  CreateDirectory(buf, NULL);

  strcat(strcpy(buf, userdir), "\\lib\\ext");  
  CreateDirectory(buf, NULL);

  strcat(strcpy(buf, userdir), "\\lib\\patches");
  CreateDirectory(buf, NULL);

  strcat(strcpy(buf, fortehome), "\\Development");
  strcat(strcpy(buf2, userdir), "\\Development");
  CreateDirectory(buf2, NULL);
  copyTree(buf2, buf);
  
 quit:

  SetCursor(normal);
  DestroyCursor(wait);
  DestroyCursor(normal);
  return rc;
}

int copyTree(char *dst, char *src) {
  char buf[MAX_PATH], buf2[MAX_PATH];  
  WIN32_FIND_DATA ffd;
  HANDLE ffh, fh;
  
  memset(&ffd, 0, sizeof ffd);
  strcat(strcpy(buf, src), "\\*.*");
  ffh = FindFirstFile(buf, &ffd);
  if (ffh == INVALID_HANDLE_VALUE) {
    return 1;
  }

  do {
    if (0 == strcmp(".", ffd.cFileName) || 0 == strcmp("..", ffd.cFileName))
      continue;
    
    strcat(strcat(strcpy(buf, src), "\\"), ffd.cFileName);
    strcat(strcat(strcpy(buf2, dst), "\\"), ffd.cFileName);
    
    if (ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
      CreateDirectory(buf2, NULL);
      copyTree(buf2, buf);
    } else {
      CopyFile(buf, buf2, TRUE);
    }
  } while (FindNextFile(ffh, &ffd));

  FindClose(ffh);
  return 1;
}

#ifdef WINMAIN

int WINAPI
WinMain (HINSTANCE hSelf, HINSTANCE hPrev, LPSTR cmdline, int nShow)
{
  //
  // validate arguments, setup the userdir
  //
  
  char buf[MAX_PATH], *pc;
  
  GetModuleFileName(0, buf, sizeof buf);

  pc = strrchr(buf, '\\');
  if (pc != NULL) {             // always holds
    strlwr(pc + 1);
    if (strstr(pc + 1, "_multiuser") != NULL)
      multiuser = 1;
    *pc = '\0';	// remove .exe filename
  }

  // remove \bin
  pc = strrchr(buf, '\\');
  if (pc != NULL && 0 == stricmp("\\bin", pc))
    *pc = '\0';
  strcpy(fortehome, buf);

  findJdkFromRegistry(JDK_KEY, jdkhome);
  parseCommandLine(DEFAULT_ARGS);
  parseForteCfg(fortehome);
  parseArgs(__argc - 1, __argv + 1); // skip progname

  if (multiuser) {
    if (userdir[0] == '\0') {
      if (!getUserDir(userdir))
        exit(1);
    }
    if (setupUserDirIfNeeded(fortehome, userdir))
      fatal(getStringRes(MSG_CANNOT_SETUP_USERDIR));
  }

  //
  // launch the console loader in hidden mode
  //
  
  STARTUPINFO start;
  PROCESS_INFORMATION child;

  multiuser = 0;
  
  GetModuleFileName(0, buf, sizeof buf);
  pc = strrchr(buf, '\\');
  if (pc != NULL) {             // always holds
    strlwr(pc + 1);
    if (strstr(pc + 1, "_multiuser") != NULL)
      multiuser = 1;
    *pc = '\0';	// remove .exe filename
  }
  if (multiuser)
    strcat(buf, "\\forte4j_multiuser.exe");
  else
    strcat(buf, "\\forte4j.exe");

  memset (&start, 0, sizeof (start));
  start.cb = sizeof (start);
  start.dwFlags = STARTF_USESHOWWINDOW;
  start.wShowWindow = SW_HIDE;
  
  if (!CreateProcess (buf, GetCommandLine(),
                      NULL, NULL, TRUE, NORMAL_PRIORITY_CLASS,
                      NULL, NULL, &start, &child)) {
    MessageBox(NULL, getStringRes(MSG_CANNOT_START_FORTE4J),
               PROG_FULLNAME, MB_ICONSTOP | MB_OK);
    return 1;
  } else
    return 0;
}

#endif
