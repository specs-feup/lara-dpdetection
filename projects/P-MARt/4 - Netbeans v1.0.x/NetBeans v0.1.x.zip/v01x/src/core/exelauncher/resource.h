//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by forte4j.rc
//
#define USERDIR_DLG                     100
#define FORTEICON                       101
#define IDC_LOCATION                    1000
#define IDC_BROWSE                      1001
#define IDC_USERDIR                     1002

#define IDC_STATIC                      -1

#define MSG_CANNOT_SETUP_USERDIR         201
#define MSG_CANNOT_FIND_JDK              202
#define MSG_CANNOT_FIND_JNI_CreateJavaVM 203
#define MSG_CANNOT_FIND_CLASS            204
#define MSG_CANNOT_CREATE_JVM            205
#define MSG_CANNOT_FIND_METHOD_MAIN      206
#define MSG_OUT_OF_MEM                   207
#define MSG_USAGE                        208
#define MSG_MUST_ENTER_DIRECTORY         209
#define MSG_CANNOT_START_FORTE4J         210
#define MSG_CANNOT_LOAD_JVM              211

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        300
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

