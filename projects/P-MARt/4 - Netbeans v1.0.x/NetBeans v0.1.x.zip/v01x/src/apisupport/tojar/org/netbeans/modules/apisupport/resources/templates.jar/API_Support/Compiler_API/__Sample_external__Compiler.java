/*
* __NAME__.java
*/ 

package Templates.API_Support.Compiler_API;

import java.util.*;

import org.openide.compiler.*;
import org.openide.compiler.Compiler;
import org.openide.execution.NbProcessDescriptor;
import org.openide.filesystems.FileObject;
import org.openide.filesystems.FileUtil;

public class __Sample_external__Compiler extends ExternalCompiler {

    private boolean building;
    private String myOpt;

    public __NAME__ (boolean building, FileObject primFile, NbProcessDescriptor compiler,
                     ExternalCompiler.ErrorExpression errExpr, String myOpt) {
        super (primFile, building ? BUILD : COMPILE, compiler, errExpr);
        this.building = building;
        this.myOpt = myOpt;
    }

    // This is important to write correctly!
    public boolean equals (Object o) {
        if (! super.equals (o)) return false;
        if (! (o instanceof __NAME__)) return false;
        __NAME__ other = (__NAME__) o;
        // Add any other equality comparisons you may need,
        // according to the instance variables:
        return myOpt.equals (other.myOpt) &&
               building == other.building;
    }

    // Also, this must be the same for equal compilers!
    public int hashCode () {
        return 9876 ^ getFileObject ().getPackageNameExt ('/', '.').hashCode ();
    }

    // Store this information for use by the compiler group.
    public String getMyOpt () {
        return myOpt;
    }

    public boolean isUpToDate () {
        // Always recompile when building.
        if (building) return false;
        // Otherwise, check neighboring files, e.g., for an extension
        // produced only by the compiler.
        FileObject fo = getFileObject ();
        FileObject compiled = FileUtil.findBrother (fo, "compiledExt");
        // If no compiled file, then of course it is not up-to-date.
        if (compiled == null) return false;
        // Else, check timestamps.
        return compiled.lastModified ().after (fo.lastModified ());
    }

    // Just specify the kind of compiler group to use. Its default constructor will be called.
    public Class compilerGroupClass () {
        return __NAME$Compiler$CompilerGroup$MyCompilerGroup__.class;
    }

    // Make sure these compilers are split into separate groups if they do not
    // agree on the value of myOpt.
    public Object compilerGroupKey () {
        List l = new ArrayList (2);
        l.add (super.compilerGroupKey ());
        l.add (getMyOpt ());
        return l;
    }

}
