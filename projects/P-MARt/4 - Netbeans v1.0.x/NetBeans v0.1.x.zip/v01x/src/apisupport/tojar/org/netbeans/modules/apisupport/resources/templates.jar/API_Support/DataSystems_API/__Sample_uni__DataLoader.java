/*
* __NAME__.java
*/ 

package Templates.API_Support.DataSystems_API;

import java.io.IOException;

import org.openide.actions.*;
import org.openide.filesystems.*;
import org.openide.loaders.*;
import org.openide.util.actions.SystemAction;

/** Recognizes single files in the Repository as being of a certain type.
 *
 * @author __USER__
 */
public class __Sample_uni__DataLoader extends UniFileLoader {

    public __NAME__ () {
        this (__NAME$DataLoader$DataObject$MyDataObject__.class);
    }

    public __NAME__ (Class recognizedObject) {
        super (recognizedObject);
    }

    protected void initialize () {

        setDisplayName (__NAME__BeanInfo.getString ("LBL_loaderName"));

        ExtensionList extensions = new ExtensionList ();
        extensions.addExtension ("qqq");
        extensions.addExtension ("xyzyy");
        setExtensions (extensions);

        setActions (new SystemAction[] {
                        SystemAction.get (OpenAction.class),
                        // SystemAction.get (CustomizeBeanAction.class),
                        SystemAction.get (FileSystemAction.class),
                        null,
                        /*
                        SystemAction.get (CompileAction.class),
                        null,
                        SystemAction.get (ExecuteAction.class),
                        null,
                        */
                        SystemAction.get (CutAction.class),
                        SystemAction.get (CopyAction.class),
                        SystemAction.get (PasteAction.class),
                        null,
                        SystemAction.get (DeleteAction.class),
                        SystemAction.get (RenameAction.class),
                        null,
                        SystemAction.get (SaveAsTemplateAction.class),
                        null,
                        SystemAction.get (ToolsAction.class),
                        SystemAction.get (PropertiesAction.class),
                    });

    }

    protected MultiDataObject createMultiObject (FileObject primaryFile)
    throws DataObjectExistsException, IOException {
        return new __NAME$DataLoader$DataObject$MultiDataObject__ (primaryFile, this);
    }

    /* Useful if creating an EditorSupport:
    static {
      FileUtil.setMIMEType ("qqq", "text/x-qqq-descriptor");
}
    */

    // Additional user-configurable properties:
    /*
    public String getMyProp () {
      return (String) getProperty ("myProp");
}
    public void setMyProp (String nue) {
      putProperty ("myProp", nue, true);
}
    public void writeExternal (ObjectOutput out) throws IOException {
      super.writeExternal (out);
      out.writeUTF (getMyProp ());
}
    public void readExternal (ObjectInput in) throws IOException, ClassNotFoundException {
      super.readExternal (in);
      setMyProp (in.readUTF ());
}
    */

}
