/*
* __NAME__.java
*/ 

package Templates.API_Support.Compiler_API;

import java.awt.Image;
import java.beans.*;

import org.openide.compiler.ExternalCompilerType;
import org.openide.util.NbBundle;

/** Description of the compiler type.
 *
 * @author __USER__
 */
public class __Sample_external__CompilerTypeBeanInfo extends SimpleBeanInfo {

    // Inherit properties and so on from ExternalCompilerType.
    public BeanInfo[] getAdditionalBeanInfo () {
        try {
            return new BeanInfo[] {
                       Introspector.getBeanInfo (ExternalCompilerType.class)
                   };
        } catch (IntrospectionException ie) {
            if (Boolean.getBoolean ("netbeans.debug.exceptions"))
                ie.printStackTrace ();
            return null;
        }
    }

    public BeanDescriptor getBeanDescriptor () {
        // Here is where to include a customizer class if you have one:
        BeanDescriptor desc = new BeanDescriptor (__NAME$CompilerTypeBeanInfo$CompilerType$MyCompilerType__.class);
        // Display name also serves as default for instances:
        desc.setDisplayName (NbBundle.getBundle (__NAME__.class).getString (__QUOTES__LABEL___NAME$CompilerTypeBeanInfo$CompilerType$MyCompilerType____QUOTES__));
        desc.setShortDescription (NbBundle.getBundle (__NAME__.class).getString (__QUOTES__HINT___NAME$CompilerTypeBeanInfo$CompilerType$MyCompilerType____QUOTES__));
        return desc;
    }

    public PropertyDescriptor[] getPropertyDescriptors () {
        try {
            PropertyDescriptor valueOfMyOption = new PropertyDescriptor ("valueOfMyOption", __NAME$CompilerTypeBeanInfo$CompilerType$MyCompilerType__.class);
            valueOfMyOption.setDisplayName (NbBundle.getBundle (__NAME__.class).getString ("PROP_valueOfMyOption"));
            valueOfMyOption.setShortDescription (NbBundle.getBundle (__NAME__.class).getString ("HINT_valueOfMyOption"));
            // If you wish to provide a custom set of preconfigured error expressions:
            /*
            PropertyDescriptor errorExpression = new PropertyDescriptor ("errorExpression", __NAME$CompilerTypeBeanInfo$CompilerType$MyCompilerType__.class);
            errorExpression.setDisplayName (NbBundle.getBundle (__NAME__.class).getString ("PROP_errorExpression"));
            errorExpression.setShortDescription (NbBundle.getBundle (__NAME__.class).getString ("HINT_errorExpression"));
            errorExpression.setPropertyEditorClass (ErrExprEd.class);
            */
            return new PropertyDescriptor[] { valueOfMyOption /* , errorExpression */ };
        } catch (IntrospectionException ie) {
            if (Boolean.getBoolean ("netbeans.debug.exceptions"))
                ie.printStackTrace ();
            return null;
        }
    }

    private static Image icon, icon32;
    public Image getIcon (int type) {
        if (type == BeanInfo.ICON_COLOR_16x16 || type == BeanInfo.ICON_MONO_16x16) {
            if (icon == null)
                icon = loadImage (__QUOTES____NAME$CompilerTypeBeanInfo$CompilerIcon$MyIcon__.gif__QUOTES__);
            return icon;
        } else {
            if (icon32 == null)
                icon32 = loadImage (__QUOTES____NAME$CompilerTypeBeanInfo$CompilerIcon32$MyIcon32__.gif__QUOTES__);
            return icon32;
        }
    }

    /*
    public static class ErrExprEd extends org.openide.explorer.propertysheet.editors.ExternalCompiler.ErrorExpressionEditor {

      public ErrExprEd () {
        super (makeCollection ());
      }

      private static Collection makeCollection () {
        java.util.List list = new java.util.ArrayList ();
        list.addAll (java.util.Arrays.asList (__NAME$CompilerTypeBeanInfo$CompilerType$MyCompilerType__.ERROR_EXPRS));
        return list;
      }

}
    */

}
