/*
* __NAME__.java
*/ 

package Templates.API_Support.Compiler_API;

import java.io.IOException;
import java.util.*;

import org.openide.compiler.*;
import org.openide.compiler.Compiler;
import org.openide.filesystems.*;

/** Does the work of cleaning up after an external compiler.
 *
 * @author __USER__
 */
public class __Sample__CleanCompilerGroup extends CompilerGroup {
    /**
     * @associates Compiler 
     */
    private Set compilers = new HashSet (); // Set<__NAME$CleanCompilerGroup$CleanCompiler$MyCleanCompiler__>

    public void add (Compiler c) throws IllegalArgumentException {
        if (! (c instanceof __NAME$CleanCompilerGroup$CleanCompiler$MyCleanCompiler__)) throw new IllegalArgumentException ();
        compilers.add (c);
    }

    public boolean start () {
        boolean ok = true;
        Iterator it = compilers.iterator ();
        while (it.hasNext ()) {
            __NAME$CleanCompilerGroup$CleanCompiler$MyCleanCompiler__ c = (__NAME$CleanCompilerGroup$CleanCompiler$MyCleanCompiler__) it.next ();
            if (c.isUpToDate ()) continue;
            FileObject fo = c.getFileObject ();
            FileObject toKill = FileUtil.findBrother (fo, "compiledExt");
            if (toKill == null) continue;
            try {
                FileLock lock = toKill.lock ();
                try {
                    toKill.delete (lock);
                    fireProgressEvent (new ProgressEvent (this, fo, ProgressEvent.TASK_WRITING));
                } finally {
                    lock.releaseLock ();
                }
            } catch (IOException ioe) {
                fireErrorEvent (new ErrorEvent (this, toKill, 0, 0, ioe.toString (), null));
                ok = false;
            }
        }
        return ok;
    }

}
