package Templates.API_Support;
import java.beans.*;
import java.io.*;
import java.util.*;
import org.openide.*;
import org.openide.actions.*;
import org.openide.awt.*;
import org.openide.compiler.*;
import org.openide.compiler.Compiler; // override java.lang.Compiler
import org.openide.cookies.*;
import org.openide.debugger.*;
import org.openide.execution.*;
import org.openide.explorer.*;
import org.openide.explorer.propertysheet.*;
import org.openide.explorer.propertysheet.editors.*;
import org.openide.explorer.view.*;
import org.openide.filesystems.*;
import org.openide.filesystems.FileSystem; // override java.io.FileSystem
import org.openide.loaders.*;
import org.openide.modules.*;
import org.openide.nodes.*;
import org.openide.options.*;
import org.openide.src.*;
import org.openide.src.nodes.*;
import org.openide.text.*;
import org.openide.util.*;
import org.openide.util.actions.*;
import org.openide.util.datatransfer.*;
import org.openide.util.enum.*;
import org.openide.util.io.*;
import org.openide.windows.*;
/** Run some simple test using internal execution. All APIs are easily available. */
public class API_test_script {
    public static void main (String ignore[]) throws Exception {
        // Some test code, e.g.:
        // DataObject dob = getDO ("samples", "Foo", "java"); print (dob);
        // SourceCookie cookie = (SourceCookie) dob.getCookie (SourceCookie.class); print (cookie);
        // ClassElement clazz = cookie.getSource ().getClasses ()[0]; print (clazz);
        // clazz.addMethod (...); print (clazz);
        // SaveCookie save = (SaveCookie) dob.getCookie (SaveCookie.class); print (save);
        // save.save ();
    }
    /** Print some object to stderr. */
    public static void print (Object text) {
        System.err.println (text);
    }
    /** Get the TopManager. */
    public static TopManager tm () {
        TopManager tm = TopManager.getDefault ();
        if (tm == null) {
            throw new RuntimeException ("use internal execution please");
        } else {
            return tm;
        }
    }
    /** Get a file object by name. */
    public static FileObject getFO (String pkg, String name, String ext) throws Exception {
        FileObject fo = tm ().getRepository ().find (pkg, name, ext);
        if (fo == null)
            throw new Exception ("No such file object: " + pkg + " " + name + " " + ext);
        else
            return fo;
    }
    /** Get a data object by name. */
    public static DataObject getDO (String pkg, String name, String ext) throws Exception {
        return DataObject.find (getFO (pkg, name, ext));
    }
}
