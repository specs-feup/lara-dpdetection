/*
* __NAME__.java
*/ 

package Templates.API_Support.Compiler_API;

import org.openide.compiler.*;
import org.openide.compiler.Compiler;
import org.openide.filesystems.FileObject;
import org.openide.filesystems.FileUtil;

/** Cleans up after an external compiler.
 *
 * @author __USER__
 */
public class __Sample__CleanCompiler extends Compiler {

    private FileObject fo;

    public __NAME__ (FileObject fo) {
        this.fo = fo;
    }

    // This is important to write correctly!
    public boolean equals (Object o) {
        if (! (o instanceof __NAME__)) return false;
        __NAME__ other = (__NAME__) o;
        // Add any other equality comparisons you may need,
        // according to the instance variables:
        return fo.getFileSystem ().getSystemName ().equals (other.fo.getFileSystem ().getSystemName ()) &&
               fo.getPackageNameExt ('/', '.').equals (other.fo.getPackageNameExt ('/', '.'));
    }

    // Also, this must be the same for equal compilers!
    public int hashCode () {
        return 1234 ^ fo.getPackageNameExt ('/', '.').hashCode ();
    }

    /*
    // Only needed if you wish to automatically break apart
    // these compilers into different groups:
    public Object compilerGroupKey () {
      List l = new ArrayList (2);
      l.add (super.compilerGroupKey ());
      l.add (someThingUniqueToMe);
      return l;
}
    */

    public Class compilerGroupClass () {
        return __NAME$CleanCompiler$CleanCompilerGroup$MyCleanCompilerGroup__.class;
    }

    public boolean isUpToDate () {
        // Just check if there is anything to clean.
        return FileUtil.findBrother (fo, "compiledExt") == null;
    }

    // For use by the compiler group:
    public FileObject getFileObject () {
        return fo;
    }

}
