/*
* __NAME__.java
*/ 

package Templates.API_Support.Actions_API;

import org.openide.nodes.Node;
import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;
import org.openide.util.actions.NodeAction;

/** Action sensitive to the node selection that does something useful.
 *
 * @author  __USER__
 */
public class __Sample_node__Action extends NodeAction {

    protected void performAction (Node[] nodes) {
        // do work based on the current node selection, e.g.:
        MyKindOfNode node = (MyKindOfNode) nodes[0];
        // ...
    }

    protected boolean enable (Node[] nodes) {
        // e.g.:
        return nodes.length == 1 && nodes[0] instanceof MyKindOfNode;
    }

    public String getName () {
        return NbBundle.getBundle (__NAME__.class).getString (__QUOTES__displayNameFor__NAME____QUOTES__);
    }

    protected String iconResource () {
        return __QUOTES____NAME__Icon.gif__QUOTES__;
    }

    public HelpCtx getHelpCtx () {
        return HelpCtx.DEFAULT_HELP;
        // If you will provide context help then use:
        // return new HelpCtx (__NAME__.class);
    }

    /** Perform extra initialization of this action's singleton.
    * PLEASE do not use constructors for this purpose!
    protected void initialize () {
      super.initialize ();
      putProperty ("someProp", value);
}
    */

}
