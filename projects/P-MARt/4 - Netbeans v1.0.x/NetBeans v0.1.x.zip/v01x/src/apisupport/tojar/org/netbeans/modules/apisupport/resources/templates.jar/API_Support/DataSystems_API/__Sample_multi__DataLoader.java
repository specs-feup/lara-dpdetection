/*
* __NAME__.java
*/ 

package Templates.API_Support.DataSystems_API;

import java.io.IOException;

import org.openide.actions.*;
import org.openide.filesystems.FileObject;
import org.openide.filesystems.FileUtil;
import org.openide.loaders.*;
import org.openide.util.actions.SystemAction;

/** Recognizes some set of files in the Repository as belonging together.
 *
 * @author __USER__
 */
public class __Sample_multi__DataLoader extends MultiFileLoader {

    /** Extension used by primary file which must be present. */
    private static final String MAIN_EXT = "qqq";
    /** Extension used by optional secondary file. */
    private static final String SECONDARY_EXT = "xyzzy";

    public __NAME__ () {
        this (__NAME$DataLoader$DataObject$MyDataObject__.class);
    }

    public __NAME__ (Class recognizedObject) {
        super (recognizedObject);
    }

    protected void initialize () {

        setDisplayName (__NAME__BeanInfo.getString ("LBL_loaderName"));

        setActions (new SystemAction[] {
                        SystemAction.get (OpenAction.class),
                        // SystemAction.get (CustomizeBeanAction.class),
                        SystemAction.get (FileSystemAction.class),
                        null,
                        /*
                        SystemAction.get (CompileAction.class),
                        null,
                        SystemAction.get (ExecuteAction.class),
                        null,
                        */
                        SystemAction.get (CutAction.class),
                        SystemAction.get (CopyAction.class),
                        SystemAction.get (PasteAction.class),
                        null,
                        SystemAction.get (DeleteAction.class),
                        SystemAction.get (RenameAction.class),
                        null,
                        SystemAction.get (SaveAsTemplateAction.class),
                        null,
                        SystemAction.get (ToolsAction.class),
                        SystemAction.get (PropertiesAction.class),
                    });

    }

    protected FileObject findPrimaryFile (FileObject fo) {
        // This can of course be much more sophisticated.
        if (fo.hasExt (MAIN_EXT))
            return fo;
        else if (fo.hasExt (SECONDARY_EXT))
            return FileUtil.findBrother (fo, MAIN_EXT);
        else
            return null;
    }

    protected MultiDataObject createMultiObject (FileObject primaryFile)
    throws DataObjectExistsException, IOException {
        return new __NAME$DataLoader$DataObject$MyDataObject__ (primaryFile, this);
    }

    protected MultiDataObject.Entry createPrimaryEntry (MultiDataObject obj, FileObject primaryFile) {
        // Entry for the important file: by default, is preserved during all operations.
        return new FileEntry (obj, primaryFile);
        // return new __NAME$DataLoader$Format$Format__ (obj, primaryFile);
    }
    /* How to substitute e.g. "<<<FILESIZE>>>" -> "2933".
    public static class __NAME$DataLoader$Format$Format__ extends FileEntry.Format {
      public __NAME$DataLoader$Format$Format__ (MultiDataObject obj, FileObject primaryFile) {
        super (obj, primaryFile);
      }
      protected java.text.Format createFormat (FileObject target, String name, String ext) {
        java.util.Map map = new java.util.HashMap (2);
        map.put ("NAME", name);
        map.put ("FILESIZE", new Long (target.getSize));
        org.openide.util.MapFormat format = new org.openide.util.MapFormat (map);
        format.setLeftBrace ("<<<");
        format.setRightBrace (">>>");
        return format;
      }
}
    */

    protected MultiDataObject.Entry createSecondaryEntry (MultiDataObject obj, FileObject secondaryFile) {
        secondaryFile.setImportant (false);
        return new FileEntry.Numb (obj, secondaryFile); // discard whenever needed
    }

    /* Useful if creating an EditorSupport:
    static {
      FileUtil.setMIMEType (MAIN_EXT, "text/x-qqq-descriptor");
}
    */

    // Additional user-configurable properties:
    /*
    public String getMyProp () {
      return (String) getProperty ("myProp");
}
    public void setMyProp (String nue) {
      putProperty ("myProp", nue, true);
}
    public void writeExternal (ObjectOutput out) throws IOException {
      super.writeExternal (out);
      out.writeUTF (getMyProp ());
}
    public void readExternal (ObjectInput in) throws IOException, ClassNotFoundException {
      super.readExternal (in);
      setMyProp (in.readUTF ());
}
    */

}
