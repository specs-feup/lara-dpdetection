/*
* __NAME__.java
*/ 

package Templates.API_Support.Execution_API;

import java.awt.Image;
import java.beans.*;

import org.openide.execution.ThreadExecutor;
import org.openide.util.NbBundle;

/** Description of the executor.
 *
 * @author __USER__
 */
public class __Sample_internal__ExecutorBeanInfo extends SimpleBeanInfo {

    // Inherit properties and so on from Executor.
    public BeanInfo[] getAdditionalBeanInfo () {
        try {
            return new BeanInfo[] {
                       Introspector.getBeanInfo (ThreadExecutor.class)
                   };
        } catch (IntrospectionException ie) {
            if (Boolean.getBoolean ("netbeans.debug.exceptions"))
                ie.printStackTrace ();
            return null;
        }
    }

    public BeanDescriptor getBeanDescriptor () {
        // Here is where to include a customizer class if you have one:
        BeanDescriptor desc = new BeanDescriptor (__NAME$ExecutorBeanInfo$Executor$MyExecutor__.class);
        // Display name also serves as default for instances:
        desc.setDisplayName (NbBundle.getBundle (__NAME__.class).getString (__QUOTES__LABEL___NAME$ExecutorBeanInfo$Executor$MyExecutor____QUOTES__));
        desc.setShortDescription (NbBundle.getBundle (__NAME__.class).getString (__QUOTES__HINT___NAME$ExecutorBeanInfo$Executor$MyExecutor____QUOTES__));
        return desc;
    }

    public PropertyDescriptor[] getPropertyDescriptors () {
        try {
            PropertyDescriptor myProp = new PropertyDescriptor ("myProp", __NAME$ExecutorBeanInfo$Executor$MyExecutor__.class);
            myProp.setDisplayName (NbBundle.getBundle (__NAME__.class).getString ("PROP_myProp"));
            myProp.setShortDescription (NbBundle.getBundle (__NAME__.class).getString ("HINT_myProp"));
            return new PropertyDescriptor[] { myProp };
        } catch (IntrospectionException ie) {
            if (Boolean.getBoolean ("netbeans.debug.exceptions"))
                ie.printStackTrace ();
            return null;
        }
    }

    private static Image icon, icon32;
    public Image getIcon (int type) {
        if (type == BeanInfo.ICON_COLOR_16x16 || type == BeanInfo.ICON_MONO_16x16) {
            if (icon == null)
                icon = loadImage (__QUOTES____NAME$ExecutorBeanInfo$ExecutorIcon$MyIcon__.gif__QUOTES__);
            return icon;
        } else {
            if (icon32 == null)
                icon32 = loadImage (__QUOTES____NAME$ExecutorBeanInfo$ExecutorIcon32$MyIcon32__.gif__QUOTES__);
            return icon32;
        }
    }

}
