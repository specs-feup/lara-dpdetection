/*
* __NAME__.java
*/

package Templates.API_Support.Nodes_API;

import org.openide.nodes.*;

/** Customizes display of filtered children.
 *
 * @author __USER__
 */
public class __Sample_filter__Children extends FilterNode.Children {

    public __NAME__ (Node orig) {
        // This is the original parent node:
        super (orig);
    }

    public Object clone () {
        return new __NAME__ (original);
    }

    protected Node copyNode (Node child) {
        // Perhaps create a customized child somehow, e.g. recurse:
        return new __NAME$Children$Node$MyFilterNode__ (child);
    }

    // If you need to display 0 or >1 nodes for one original child, you must
    // directly override this:
    /*
    protected Node[] createNodes (Object key) {
      Node child = (Node) key;
      SomeCookie cookie = (SomeCookie) child.getCookie (SomeCookie.class);
      if (cookie != null) {
        // Represent and also show something else besides, for example.
        return new Node[] { child.cloneNode (), new ExtraInfoNode (cookie) };
      } else {
        // Do not represent.
        return new Node[] { };
      }
}
    */

}
