<?xml version='1.0' encoding='ISO-8859-1' ?>
<!DOCTYPE helpset PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 1.0//EN" "http://java.sun.com/products/javahelp/helpset_1_0.dtd">
<helpset version="1.0">
  <!-- Display name of this piece of help. -->
  <title>Documentation for My Module</title>
  <maps>
     <!-- This will be used as the main description of the module. -->
     <homeID>__LIKELY_HOME_ID__</homeID>
     <!-- A link to map giving actual URLs. -->
     <mapref location=__LIKELY_MAP_URL_QUOTED__/>
     <!--
     You could add additional help maps here.
     HOWEVER JavaHelp 1.0 will give an error if you do so.
     So please try to put everything in one map for now.
     -->
  </maps>
  <!--
  Navigation views you can add.
  PLEASE use the <name>'s given here, but you can feel
  free to change the <label>. Keeping the same name is
  important to let these views be merged into the master.
  -->
  <view>
    <name>TOC</name>
    <label>Contents</label>
    <type>javax.help.TOCView</type>
    <data>__LIKELY_TOC_URL__</data>
  </view>
  <view>
    <name>Index</name>
    <label>Index</label>
    <type>javax.help.IndexView</type>
    <data>__LIKELY_INDEX_URL__</data>
  </view>
  <!-- No template for this one, you will need a JavaHelp authoring tool:
  <view>
    <name>Search</name>
    <label>Search</label>
    <type>javax.help.SearchView</type>
    <data engine="com.sun.java.help.search.DefaultSearchEngine">JavaHelpSearch</data>
  </view>
  -->
</helpset>
