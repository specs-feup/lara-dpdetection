/*
* __NAME__.java
*/

package Templates.API_Support.Nodes_API;

import org.openide.nodes.*;

/** A customized filter node.
 *
 * @author __USER__
 */
public class __Sample_filter__Node extends FilterNode {

    public __NAME__ (Node original) {
        super (original, new __NAME$Node$Children$MyChildren__ (original));
        // Or if you just want to copy all the children as plain FilterNode's
        // (or acc. to Node.cloneNode) you can use:
        // super (original);
        // If you wish to operate on the filter node, instead of / in addition to the original,
        // for basic node operations, you should use e.g.:
        // disableDelegation (DELEGATE_DESTROY | DELEGATE_SET_DISPLAY_NAME);
        // Then you can customize some parts, e.g.:
        // super.setDisplayName (MessageFormat.format (NbBundle.getBundle (__NAME__.class).getString ("LBL_FilterNode_display_name_format"),
        //                                             new Object[] { getDisplayName () }));
        // To change the icon, you must use getIcon -- there is no icon resource, you
        // must load it yourself.
    }

    public Node cloneNode () {
        // Usually you will want to override this if you are subclassing.
        // Otherwise a filter of a filter is created, which works but is not ideal.
        return new __NAME__ (getOriginal ());
    }

    /*
    // Often you will want to override this if you are subclassing.
    // Otherwise the filter node cannot be persisted, so for example
    // Explorer windows rooted at it will not be correctly restored.
    public Node.Handle getHandle () {
      Node.Handle origHandle = getOriginal ().getHandle ();
      // Simplest behavior: just store the original node and try to recreate
      // a filter based on that.
      if (origHandle != null)
        return new __NAME$Node$Handle$NodeHandle__ (origHandle);
      else
        return null; // cannot persist original, do not persist filter
}
    // Note that this class should be static and is serializable:
    private static class __NAME$Node$Handle$NodeHandle__ extends Node.Handle {
      private Node.Handle origHandle; // the only serializable state
      public __NAME$Node$Handle$NodeHandle__ (Node.Handle origHandle) {
        this.origHandle = origHandle;
      }
      public Node getNode () throws IOException {
        // Simplest behavior. If you have more configuration present in the filter,
        // for example additional options to the constructor, you will probably need
        // to manually store them or otherwise know how to recreate them.
        return new __NAME__ (origHandle);
      }
}
    */

    // To override handling of e.g. node destruction, you may:
    /*
    public boolean canDestroy () {
      return true;
}
    public void destroy () throws IOException {
      super.destroy (); // if you have disabled DELEGATE_DESTROY, this destroys this node
      // getOriginal ().destroy (); // you might wish to destroy both
      // Can perform other actions here to your liking.
}
    */

    // To add cookies:
    /*
    public Node.Cookie getCookie (Class clazz) {
      if (clazz.isAssignableFrom (MySupportedCookie.class))
        return new MyCookieSupport (getOriginal ());
      else
        return getOriginal ().getCookie (clazz);
}
    */

    // To add properties, cumbersome but straightforward:
    /*
    public Node.PropertySet[] getPropertySets () {
      Node.PropertySet[] pss = getOriginal ().getPropertySets ();
      final Node.Property myProp = new SomethingProp (getOriginal ());
      int found = -1;
      for (int i = 0; i < pss.length; i++) {
        if (pss[i].getName ().equals (Sheet.PROPERTIES)) {
          found = i;
          break;
        }
      }
      Node.PropertySet[] nue;
      if (found != -1) {
        nue = new Node.PropertySet[pss.length];
        for (int i = 0; i < pss.length; i++) {
          if (i == found) {
            final Node.PropertySet oldps = pss[i];
            nue[i] = new Node.PropertySet () {
              public void Node.Property[] getProperties () {
                Node.PropertySet[] result = new Node.PropertySet[oldps.length + 1];
                System.arraycopy (oldps, 0, result, 0, oldps.length);
                result[oldps.length] = myProp;
                return result;
              }
            };
            nue[i].setName (oldps.getName ());
            nue[i].setDisplayName (oldps.getDisplayName ());
            nue[i].setShortDescription (oldps.getShortDescription ());
          } else {
            nue[i] = pss[i];
          }
        }
      } else {
        nue = new Node.PropertySet[pss.length + 1];
        Node.PropertySet added = new Node.PropertySet () {
          public void Node.Property[] getProperties () {
            return myProp;
          }
        };
        added.setName (Sheet.PROPERTIES);
        added.setDisplayName (NbBundle.getBundle (__NAME__.class).getString ("LBL_AddedSheet"));
        added.setShortDescription (NbBundle.getBundle (__NAME__.class).getString ("HINT_AddedSheet"));
        System.arraycopy (pss, 0, nue, 0, pss.length);
        nue[pss.length] = added;
      }
      return nue;
}
    */

}
