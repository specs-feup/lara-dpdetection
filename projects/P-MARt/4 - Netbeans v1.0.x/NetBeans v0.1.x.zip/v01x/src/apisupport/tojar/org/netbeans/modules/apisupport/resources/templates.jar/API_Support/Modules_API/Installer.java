/*
* __NAME__.java
*/ 

package Templates.API_Support.Modules_API;

import java.io.*;

import org.openide.TopManager;
import org.openide.filesystems.FileUtil;
import org.openide.loaders.*;
import org.openide.modules.ModuleInstall;
import org.openide.util.NbBundle;
import org.openide.util.Utilities;

/** Manages a module's lifecycle.
 *
 * @author __USER__
 */
public class Installer extends ModuleInstall {

    // By default, do nothing but call restored ().
    /*
    public void installed () {
      // Copy some templates from a JAR inside the module:
      try {
        // templates.jar should have its "default package" correspond to the Templates folder;
        // it may include filesystem.attributes files which will be applied to the extracted objects,
        // which is useful for marking files as templates, giving them default executors, etc.
        FileUtil.extractJar (TopManager.getDefault ().getPlaces ().folders ().templates ().getPrimaryFile (),
                             NbBundle.getLocalizedFile (__QUOTES____PACKAGE__.templates__QUOTES__, "jar").openStream ());
      } catch (IOException ioe) {
        TopManager.getDefault ().notifyException (ioe);
      }
      // Install some actions:
      try {
        createAction (MyFirstAction.class, DataFolder.create (TopManager.getDefault ().getPlaces ().folders ().menus (), "View"),
                      "GlobalPropertiesAction", true, false, false, false, false);
        createAction (MyFirstAction.class, DataFolder.create (TopManager.getDefault ().getPlaces ().folders ().toolbars (), "View"),
                      "HTMLViewAction", true, true, true, true, false);
        // Order is unimportant here:
        InstanceDataObject.create (DataFolder.create (TopManager.getDefault ().getPlaces ().folders ().actions (), "View"),
                                   "MyFirstAction", MyFirstAction.class);
      } catch (IOException ioe) {
        if (Boolean.getBoolean ("netbeans.debug.exceptions"))
          ioe.printStackTrace ();
      }
      restored ();
}
    */

    // By default, do nothing.
    // Could install editor kits, add to the property editor search path, etc.
    /*
    public void restored () {
}
    */

    // Could try to remove templates, provided that the user has not modified them.
    // (An API call to help with this may be provided in the future.)
    // By default, do nothing.
    /*
    public void uninstalled () {
      // Remove your actions:
      try {
        removeAction (MyFirstAction.class,
                      DataFolder.create (TopManager.getDefault ().getPlaces ().folders ().menus (), "View"),
                      false);
        removeAction (MyFirstAction.class,
                      DataFolder.create (TopManager.getDefault ().getPlaces ().folders ().toolbars (), "View"),
                      true);
        InstanceDataObject.remove (DataFolder.create (TopManager.getDefault ().getPlaces ().folders ().actions (), "View"),
                                   "MyFirstAction", MyFirstAction.class);
      } catch (IOException ioe) {
        if (Boolean.getBoolean ("netbeans.debug.exceptions"))
          ioe.printStackTrace ();
      }
}
    */

    // By default, call restored ().
    // If you have changed e.g. actions since a previous release, you can
    // specify how to update the module installation, e.g.:
    /*
    public void updated (int release, String specVersion) {
      // removeAction's for the old actions
      // createAction's for the new actions
}
    */

    /** Create an action instance.
    * Goes to some effort to put it into the right place.
    * You can customize this logic according to your needs.
    * @param actionClass the class of the action to install
    * @param folder the folder to install it into
    * @param relativeTo another item it should be installed next to (identifying portion of file basename)
    * @param after if true, install after that item; else install before it
    * @param isToolbar if true, use toolbar separators, else menu separators
    * @param skipSeparator if true, install on the other side of any separator which may be there
    * @param separatorBefore if true, make sure a separator is installed before this item
    * @param separatorAfter if true, make sure a separator is installed after this item
    * @throws IOException if the creation failed
    */
    private void createAction (Class actionClass, DataFolder folder, String relativeTo, boolean after, boolean isToolbar,
                               boolean skipSeparator, boolean separatorBefore, boolean separatorAfter) throws IOException {
        String actionShortName = Utilities.getShortClassName (actionClass);
        String actionName = actionClass.getName ();

        if (InstanceDataObject.find (folder, actionShortName, actionName) != null) return;

        DataObject[] children = folder.getChildren ();
        int indexToUse = -1;
        for (int i = 0; i < children.length; i++) {
            if (children[i] instanceof InstanceDataObject &&
                    children[i].getPrimaryFile ().getName ().indexOf (relativeTo) != -1) {
                indexToUse = i;
                break;
            }
        }
        InstanceDataObject actionInstance = InstanceDataObject.create (folder, actionShortName, actionName);

        if (indexToUse != -1) {
            if (after) {
                indexToUse += 1;
                if (skipSeparator) {
                    if ((indexToUse < children.length) &&
                            (children[indexToUse].getPrimaryFile ().getName ().indexOf ("Separator") != -1)) {
                        indexToUse += 1;
                    }
                }
            } else {
                if (skipSeparator) {
                    if ((indexToUse > 0) &&
                            (children[indexToUse - 1].getPrimaryFile ().getName ().indexOf ("Separator") != -1)) {
                        indexToUse -= 1;
                    }
                }
            }

            InstanceDataObject beforeSeparator = separatorBefore ?
                                                 InstanceDataObject.create (folder, "Separator1-" + actionShortName, sepClass (isToolbar)) :
                                                 null;
            InstanceDataObject afterSeparator = separatorAfter ?
                                                InstanceDataObject.create (folder, "Separator2-" + actionShortName, sepClass (isToolbar)) :
                                                null;

            int itemsAdded = 0;
            if (separatorBefore) itemsAdded ++;
            if (separatorAfter) itemsAdded ++;
            int currentIndex = indexToUse;

            DataObject[] newOrder = new DataObject [children.length + 1 + itemsAdded];
            System.arraycopy (children, 0, newOrder, 0, indexToUse);

            if (separatorBefore) newOrder[currentIndex++] = beforeSeparator;
            newOrder[currentIndex++] = actionInstance;
            if (separatorAfter) newOrder[currentIndex++] = afterSeparator;

            System.arraycopy (children, indexToUse, newOrder, indexToUse + 1 + itemsAdded, children.length - indexToUse);
            folder.setOrder (newOrder);
        }
    }

    /** Remove a previously-installed action.
    * @param actionClass the class of action to uninstall
    * @param folder the folder it had been installed to
    * @param isToolbar if true, use toolbar separators, else menu separators
    * @throws IOException if the removal of the action failed
    */
    private void removeAction (Class actionClass, DataFolder folder, boolean isToolbar) throws IOException {
        String actionShortName = Utilities.getShortClassName (actionClass);
        if (! InstanceDataObject.remove (folder, actionShortName, actionClass.getName ()))
            throw new IOException ("Note: removal of " + actionShortName + " from " +
                                   folder.getPrimaryFile ().getPackageName ('/') + " failed");
        InstanceDataObject.remove (folder, "Separator1-" + actionShortName, sepClass (isToolbar));
        InstanceDataObject.remove (folder, "Separator2-" + actionShortName, sepClass (isToolbar));
    }

    private String sepClass (boolean isToolbar) {
        return isToolbar ? "javax.swing.JToolBar$Separator" : "javax.swing.JSeparator";
    }

    /*
    // Implementing Externalizable is useful if you need to keep state in the module
    // which is not appropriate to store in a SystemOption on a project-by-project basis;
    // typically, information needed to cleanly uninstall.

    public void writeExternal (ObjectOutput out) throws IOException {
      super.writeExternal (out);
      // write out module-scope state information
}

    public void readExternal (ObjectInput in) throws IOException, ClassNotFoundException {
      super.readExternal (in);
      // read in module-scope state information
}

    // Use getProperty and putProperty to read/write module-scope state information, not instance vars!
    */

}
