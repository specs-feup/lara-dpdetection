/*
* __NAME__.java
*/ 

package Templates.API_Support.Filesystems_API;

import java.awt.Image;
import java.beans.*;

import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;
import org.openide.explorer.propertysheet.editors.DirectoryOnlyEditor;
import org.openide.filesystems.FileSystem;

/** Description of the file system.
 *
 * @author __USER__
 */
public class __Sample__FileSystemBeanInfo extends SimpleBeanInfo {

    public BeanInfo[] getAdditionalBeanInfo () {
        try {
            return new BeanInfo[] { Introspector.getBeanInfo (FileSystem.class) };
        } catch (IntrospectionException ie) {
            if (Boolean.getBoolean ("netbeans.debug.exceptions"))
                ie.printStackTrace ();
            return null;
        }
    }

    /*
    // If you have a visual dialog to customize configuration of the file system:
    public BeanDescriptor getBeanDescriptor () {
      return new BeanDescriptor (__NAME$BeanInfo$$FileSystem__.class, __NAME$BeanInfo$Customizer$FileSystemCustomizer__.class);
}
    */

    public PropertyDescriptor[] getPropertyDescriptors () {
        try {
            // Included only to make it a writable property (it is read-only in FileSystem):
            PropertyDescriptor readOnly = new PropertyDescriptor ("readOnly", __NAME$BeanInfo$$FileSystem__.class);
            readOnly.setDisplayName (NbBundle.getBundle (__NAME__.class).getString ("PROP_readOnly"));
            readOnly.setShortDescription (NbBundle.getBundle (__NAME__.class).getString ("HINT_readOnly"));
            // This could be whatever properties you use to configure the filesystem:
            PropertyDescriptor rootDirectory = new PropertyDescriptor ("rootDirectory", __NAME$BeanInfo$$FileSystem__.class);
            rootDirectory.setDisplayName (NbBundle.getBundle (__NAME__.class).getString ("PROP_rootDirectory"));
            rootDirectory.setShortDescription (NbBundle.getBundle (__NAME__.class).getString ("HINT_rootDirectory"));
            rootDirectory.setPropertyEditorClass (RootEd.class);
            return new PropertyDescriptor[] { readOnly, rootDirectory };
        } catch (IntrospectionException ie) {
            if (Boolean.getBoolean ("netbeans.debug.exceptions"))
                ie.printStackTrace ();
            return null;
        }
    }

    private static Image icon;
    private static Image icon32;
    public Image getIcon (int type) {
        if ((type == BeanInfo.ICON_COLOR_16x16) || (type == BeanInfo.ICON_MONO_16x16)) {
            if (icon == null)
                icon = loadImage (__QUOTES__/__PACKAGE_SLASHES__/__NAME$BeanInfo$Icon$FileSystemIcon__.gif__QUOTES__);
            return icon;
        } else {
            if (icon32 == null)
                icon32 = loadImage (__QUOTES__/__PACKAGE_SLASHES__/__NAME$BeanInfo$Icon32$FileSystemIcon32__.gif__QUOTES__);
            return icon32;
        }
    }

    /** A directory chooser with special context help. */
    public static class RootEd extends DirectoryOnlyEditor {

        protected HelpCtx getHelpCtx () {
            return new HelpCtx (RootEd.class);
        }

    }

}
