/*
* __NAME__.java
*/

package Templates.API_Support.DataSystems_API;

import java.awt.Image;
import java.beans.*;
import java.text.MessageFormat;
import java.util.ResourceBundle;

import org.openide.util.NbBundle;

/** Description of {@link __NAME$DataLoaderBeanInfo$DataLoader$MyDataLoader__}.
 *
 * @author __USER__
 */
public class __Sample__DataLoaderBeanInfo extends SimpleBeanInfo {

    private static ResourceBundle bundle = null;
    private static ResourceBundle getBundle () {
        if (bundle == null) bundle = NbBundle.getBundle (__NAME__.class);
        return bundle;
    }
    static String getString (String key) {
        return getBundle ().getString (key);
    }
    static String getString (String key, Object o1) {
        return MessageFormat.format (getString (key), new Object[] { o1 });
    }
    static String getString (String key, Object o1, Object o2) {
        return MessageFormat.format (getString (key), new Object[] { o1, o2 });
    }
    static String getString (String key, Object o1, Object o2, Object o3) {
        return MessageFormat.format (getString (key), new Object[] { o1, o2, o3 });
    }
    static String getString (String key, Object o1, Object o2, Object o3, Object o4) {
        return MessageFormat.format (getString (key), new Object[] { o1, o2, o3, o4 });
    }

    // If you have additional properties:
    /*
    public PropertyDescriptor[] getPropertyDescriptors () {
      try {
        PropertyDescriptor myProp = new PropertyDescriptor ("myProp", __NAME$DataLoaderBeanInfo$DataLoader$MyDataLoader__.class);
        myProp.setDisplayName (getString ("PROP_myProp"));
        myProp.setShortDescription (getString ("HINT_myProp"));
        return new PropertyDescriptor[] { myProp };
      } catch (IntrospectionException ie) {
        if (Boolean.getBoolean ("netbeans.debug.exceptions"))
          ie.printStackTrace ();
        return null;
      }
}
    */

    public BeanInfo[] getAdditionalBeanInfo () {
        try {
            // I.e. MultiDataLoader.class or UniFileLoader.class.
            return new BeanInfo[] { Introspector.getBeanInfo (__NAME$DataLoaderBeanInfo$DataLoader$MyDataLoader__.class.getSuperclass ()) };
        } catch (IntrospectionException ie) {
            if (Boolean.getBoolean ("netbeans.debug.exceptions"))
                ie.printStackTrace ();
            return null;
        }
    }

    private static Image icon, icon32;
    public Image getIcon (int type) {
        if (type == BeanInfo.ICON_COLOR_16x16 || type == BeanInfo.ICON_MONO_16x16) {
            if (icon == null)
                icon = loadImage (__QUOTES____NAME$DataLoaderBeanInfo$DataIcon$MyIcon__.gif__QUOTES__);
            return icon;
        } else {
            if (icon32 == null)
                icon32 = loadImage (__QUOTES____NAME$DataLoaderBeanInfo$DataIcon32$MyIcon32__.gif__QUOTES__);
            return icon32;
        }
    }

}
