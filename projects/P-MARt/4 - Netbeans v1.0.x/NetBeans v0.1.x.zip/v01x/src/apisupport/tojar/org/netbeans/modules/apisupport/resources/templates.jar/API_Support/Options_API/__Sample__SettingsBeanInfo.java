/*
* __NAME__.java
*/

package Templates.API_Support.Options_API;

import java.awt.Image;
import java.beans.*;
import java.text.MessageFormat;
import java.util.ResourceBundle;

import org.openide.util.NbBundle;

/** Description of {@link __NAME$BeanInfo$$MySystemOption__}.
 *
 * @author __USER__
 */
public class __Sample__SettingsBeanInfo extends SimpleBeanInfo {

    private static ResourceBundle bundle = null;
    private static ResourceBundle getBundle () {
        if (bundle == null) bundle = NbBundle.getBundle (__NAME__.class);
        return bundle;
    }
    static String getString (String key) {
        return getBundle ().getString (key);
    }
    static String getString (String key, Object o1) {
        return MessageFormat.format (getString (key), new Object[] { o1 });
    }
    static String getString (String key, Object o1, Object o2) {
        return MessageFormat.format (getString (key), new Object[] { o1, o2 });
    }
    static String getString (String key, Object o1, Object o2, Object o3) {
        return MessageFormat.format (getString (key), new Object[] { o1, o2, o3 });
    }
    static String getString (String key, Object o1, Object o2, Object o3, Object o4) {
        return MessageFormat.format (getString (key), new Object[] { o1, o2, o3, o4 });
    }

    public PropertyDescriptor[] getPropertyDescriptors () {
        try {
            PropertyDescriptor propone = new PropertyDescriptor ("propone", __NAME$BeanInfo$$MySystemOption__.class);
            propone.setDisplayName (getString ("PROP_propone"));
            propone.setShortDescription (getString ("HINT_propone"));
            PropertyDescriptor proptwo = new PropertyDescriptor ("proptwo", __NAME$BeanInfo$$MySystemOption__.class);
            proptwo.setDisplayName (getString ("PROP_proptwo"));
            proptwo.setShortDescription (getString ("HINT_proptwo"));
            proptwo.setExpert (true);
            proptwo.setPropertyEditorClass (ProptwoEd.class);
            return new PropertyDescriptor[] { propone, proptwo };
        } catch (IntrospectionException ie) {
            if (Boolean.getBoolean ("netbeans.debug.exceptions"))
                ie.printStackTrace ();
            return null;
        }
    }

    private static Image icon, icon32;
    public Image getIcon (int type) {
        if (type == BeanInfo.ICON_COLOR_16x16 || type == BeanInfo.ICON_MONO_16x16) {
            if (icon == null)
                icon = loadImage (__QUOTES____NAME$BeanInfo$Icon$MyIcon__.gif__QUOTES__);
            return icon;
        } else {
            if (icon32 == null)
                icon32 = loadImage (__QUOTES____NAME$BeanInfo$Icon32$MyIcon32__.gif__QUOTES__);
            return icon32;
        }
    }

    public static class ProptwoEd extends PropertyEditorSupport {

        private static final String[] tags = { getString ("LBL_true"), getString ("LBL_false") };

        public String[] getTags () {
            return tags;
        }

        public String getAsText () {
            return tags[((Boolean) getValue ()).booleanValue () ? 0 : 1];
        }

        public void setAsText (String text) throws IllegalArgumentException {
            if (tags[0].equals (text))
                setValue (Boolean.TRUE);
            else if (tags[1].equals (text))
                setValue (Boolean.FALSE);
            else
                throw new IllegalArgumentException ();
        }

    }

}
