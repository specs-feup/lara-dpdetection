/*
* __NAME__.java
*/ 

package Templates.API_Support.Execution_API;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.Map;

import org.openide.execution.*;
import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;

/** Runs an external process to "execute" a type of file.
 *
 * @author __USER__
 */
public class __Sample_external__Executor extends ProcessExecutor {

    private static final NbProcessDescriptor DEFAULT = new NbProcessDescriptor (
                // PROCESS NAME:
                // This need not be the Java launcher, of course:
                "{" + Format.TAG_JAVAHOME + "}{" + Format.TAG_SEPARATOR + "}bin{" + Format.TAG_SEPARATOR + "}java",
                // LIST OF ARGUMENTS INCLUDING OPTIONS:
                // And you need not specify a classpath if that does not apply to your situation:
                "-cp {" + Format.TAG_REPOSITORY + "}" +
                "{" + Format.TAG_PATHSEPARATOR + "}" + "{" + Format.TAG_CLASSPATH + "}" +
                "{" + Format.TAG_PATHSEPARATOR + "}" + "{" + Format.TAG_LIBRARY + "} " +
                // You can modify the default format however you like, and insert or remove tags like so:
                "-myoption {" + MyFormat.TAG_MYOPTIONVAL + "} " +
                // Taken from the ExecInfo. You might prefer to pass e.g. the physical file name of the argument
                // in some custom tag you provide.
                "{" + Format.TAG_CLASSNAME + "} " +
                // Again, taken from the ExecInfo, usually set in the Property Sheet. A string with spaces
                // separating the arguments, quotes inserted as needed.
                "{" + Format.TAG_ARGUMENTS + '}',
                // DESCRIPTION FOR USER OF HOW TO MODIFY THE ARGUMENTS:
                NbBundle.getBundle (__NAME__.class).getString ("MSG_format_hint")
            );

    // The default value for an unconfigured executor.
    private String valueOfMyOption = "someDefaultValue";

    public __NAME__ () {
        // Override the default executor choice made in ProcessExecutor:
        setExternalExecutor (DEFAULT);
    }

    public String getValueOfMyOption () {
        return valueOfMyOption;
    }

    public synchronized void setValueOfMyOption (String nue) {
        String old = valueOfMyOption;
        valueOfMyOption = nue;
        firePropertyChange ("valueOfMyOption", old, nue);
    }

    protected Process createProcess (ExecInfo info) throws IOException {
        return getExternalExecutor ().exec (new MyFormat (info,
                                            getClassPath (),
                                            getBootClassPath (),
                                            getRepositoryPath (),
                                            getLibraryPath (),
                                            getValueOfMyOption ()));
    }

    /*
    public HelpCtx getHelpCtx () {
      return new HelpCtx (__NAME__.class);
}
    */

    static class MyFormat extends Format {

        // Define whatever other substitutable tags you want:
        static final String TAG_MYOPTIONVAL = "myOptionVal"; // this will appear as -myoption {myOptionVal}

        MyFormat (ExecInfo info, NbClassPath classPath, NbClassPath bootClassPath,
                  NbClassPath repositoryPath, NbClassPath libraryPath,
                  // Get the values to substitute from somewhere:
                  String valueOfMyOption) {
            // This fills in all the tags defined in Format, like TAG_LIBRARY, etc.:
            super (info, classPath, bootClassPath, repositoryPath, libraryPath);
            // Add definitions for your own tags here:
            Map map = getMap ();
            map.put (TAG_MYOPTIONVAL, valueOfMyOption);
        }

    }

}
