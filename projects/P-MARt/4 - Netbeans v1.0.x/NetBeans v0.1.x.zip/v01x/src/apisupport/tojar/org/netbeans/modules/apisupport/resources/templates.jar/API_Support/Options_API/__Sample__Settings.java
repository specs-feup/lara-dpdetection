/*
* __NAME__.java
*/ 

package Templates.API_Support.Options_API;

import org.openide.options.SystemOption;
import org.openide.util.HelpCtx;

/** Options for something or other.
 *
 * @author  __USER__
 */
public class __Sample__Settings extends SystemOption {

    // static final long serialVersionUID = ...;

    public static final String PROP_PROPONE = "propone";
    public static final String PROP_PROPTWO = "proptwo";

    // No constructor please!

    protected void initialize () {
        setPropone ("defaultValue");
        setProptwo (false);
    }

    public String displayName () {
        return __NAME__BeanInfo.getString (__QUOTES__displayNameFor__NAME____QUOTES__);
    }

    public HelpCtx getHelpCtx () {
        return HelpCtx.DEFAULT_HELP;
        // If you provide context help then use:
        // return new HelpCtx (__NAME__.class);
    }

    /** Default instance of this system option, for the convenience of associated classes. */
    static final __NAME__ DEFAULT = (__NAME__) findObject (__NAME__.class, true);

    public String getPropone () {
        return (String) getProperty (PROP_PROPONE);
    }

    public void setPropone (String propone) {
        // Automatically fires property changes if needed etc.:
        putProperty (PROP_PROPONE, propone, true);
        // If you need to start some service, or do something else with
        // an external effect, you should not use putProperty(...): keep
        // the data as a private static member, and manually modify that
        // variable and use firePropertyChange(...). Because if putProperty(...)
        // is used, getters and setters will be skipped during project save
        // and restore, which may cause problems.
    }

    public boolean isProptwo () {
        return ((Boolean) getProperty (PROP_PROPTWO)).booleanValue ();
    }

    public void setProptwo (boolean proptwo) {
        putProperty (PROP_PROPTWO, new Boolean (proptwo), true);
    }

}
