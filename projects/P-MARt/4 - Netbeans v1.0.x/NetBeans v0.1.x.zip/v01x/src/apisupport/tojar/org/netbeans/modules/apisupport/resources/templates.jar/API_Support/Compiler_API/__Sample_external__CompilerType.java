/*
* __NAME__.java
*/ 

package Templates.API_Support.Compiler_API;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.Map;

import org.openide.compiler.*;
import org.openide.compiler.Compiler;
import org.openide.cookies.CompilerCookie;
import org.openide.execution.NbProcessDescriptor;
import org.openide.loaders.DataObject;
import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;

/** Runs an external process to "compile" a type of file.
 *
 * @author __USER__
 */
public class __Sample_external__CompilerType extends ExternalCompilerType {

    /*
    static final ExternalCompiler.ErrorExpression[] ERROR_EXPRS = {
      // See docs for this class for how to construct them.
      new ExternalCompiler.ErrorExpression (NbBundle.getBundle (__NAME__.class).getString ("LBL_error_exp_1"),
                                            "(some|reg|exp|here)",
                                            1, 2, 3, 4),
      // maybe some more choices as well
};
    */

    private static final NbProcessDescriptor DEFAULT = new NbProcessDescriptor (
                // PROCESS NAME:
                // This need not be Javac, of course:
                "{" + ExternalCompilerGroup.Format.TAG_JAVAHOME + "}{" + ExternalCompilerGroup.Format.TAG_SEPARATOR + "}bin{" + ExternalCompilerGroup.Format.TAG_SEPARATOR + "}javac",
                // LIST OF ARGUMENTS INCLUDING OPTIONS:
                // And you need not specify a classpath if that does not apply to your situation:
                "-cp {" + ExternalCompilerGroup.Format.TAG_REPOSITORY + "}" +
                "{" + ExternalCompilerGroup.Format.TAG_PATHSEPARATOR + "}" + "{" + ExternalCompilerGroup.Format.TAG_CLASSPATH + "}" +
                "{" + ExternalCompilerGroup.Format.TAG_PATHSEPARATOR + "}" + "{" + ExternalCompilerGroup.Format.TAG_LIBRARY + "}" +
                "{" + ExternalCompilerGroup.Format.TAG_PATHSEPARATOR + "}" + "{" + ExternalCompilerGroup.Format.TAG_BOOTCLASSPATH + "} " +
                // You can modify the default format however you like, and insert or remove tags like so:
                "-myoption {" + __NAME$CompilerType$CompilerGroup$MyCompilerGroup__.Format.TAG_MYOPTIONVAL + "} " +
                // List of file names will go here:
                "{" + ExternalCompilerGroup.Format.TAG_FILES + '}',
                // DESCRIPTION FOR USER OF HOW TO MODIFY THE ARGUMENTS:
                NbBundle.getBundle (__NAME__.class).getString ("MSG_format_hint")
            );

    // The default value for an unconfigured compiler.
    private String valueOfMyOption = "someDefaultValue";

    public __NAME__ () {
        // Override the default process choice made in ExternalCompilerType:
        setExternalCompiler (DEFAULT);
        /*
        // Install a default error expression, out of the default list presented to the user:
        setErrorExpression (ERROR_EXPRS[0]);
        */
    }

    public String getValueOfMyOption () {
        return valueOfMyOption;
    }

    public synchronized void setValueOfMyOption (String nue) {
        String old = valueOfMyOption;
        valueOfMyOption = nue;
        firePropertyChange ("valueOfMyOption", old, nue);
    }

    /*
    public HelpCtx getHelpCtx () {
      return new HelpCtx (__NAME__.class);
}
    */

    public void prepareJob (CompilerJob job, Class type, DataObject obj) {
        Compiler cleaner;
        if (type.equals (CompilerCookie.Clean.class) ||
                type.equals (CompilerCookie.Build.class)) {
            cleaner = new __NAME$CompilerType$CleanCompiler$MyCleanCompiler__ (obj.getPrimaryFile ());
            job.add (cleaner);
        } else {
            cleaner = null;
        }
        if (type.equals (CompilerCookie.Compile.class) ||
                type.equals (CompilerCookie.Build.class)) {
            Compiler compiler = new __NAME$CompilerType$Compiler$MyCompiler__
                                (false, obj.getPrimaryFile (), getExternalCompiler (), getErrorExpression (), getValueOfMyOption ());
            job.add (compiler);
            if (cleaner != null) compiler.dependsOn (cleaner);
        } else if (cleaner == null) {
            // do not do anything--unrecognized compilation type
        }
    }

}
