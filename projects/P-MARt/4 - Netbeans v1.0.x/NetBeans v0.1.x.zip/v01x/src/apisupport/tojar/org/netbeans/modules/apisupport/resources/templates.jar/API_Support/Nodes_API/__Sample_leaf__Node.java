/*
* __NAME__.java
*/ 

package Templates.API_Support.Nodes_API;

import org.openide.actions.*;
import org.openide.nodes.*;
import org.openide.util.HelpCtx;
import org.openide.util.actions.SystemAction;

/** A simple node with no children.
 *
 * @author __USER__
 */
public class __Sample_leaf__Node extends AbstractNode {

    public __Sample_leaf__Node () {
        super (Children.LEAF);
        setIconBase (__QUOTES__/__PACKAGE_SLASHES__/__NAME$Node$NodeIcon$MyIcon____QUOTES__);
        // Whatever is most relevant to a user:
        setDefaultAction (SystemAction.get (PropertiesAction.class));
        // Set FeatureDescriptor stuff:
        setName ("preferablyUniqueNameForThisNodeAmongSiblings"); // or, super.setName if needed
        setDisplayName (NbBundle.getBundle (__NAME__.class).getString ("LBL_leaf_node"));
        setShortDescription (NbBundle.getBundle (__NAME__.class).getString ("HINT_leaf_node"));
        // Add cookies, e.g.:
        /*
        getCookieSet ().add (new OpenCookie () {
          public void open () {
            // Open something useful...
          }
    });
        */
    }

    // Create the popup menu:
    protected SystemAction[] createActions () {
        return new SystemAction[] {
                   // SystemAction.get (MyFavoriteAction.class),
                   // null,                     // separator
                   /* according to what it can do:
                   SystemAction.get (CutAction.class),
                   SystemAction.get (CopyAction.class),
                   null,
                   SystemAction.get (DeleteAction.class),
                   SystemAction.get (RenameAction.class),
                   null,
                   */
                   SystemAction.get (ToolsAction.class),
                   null,
                   SystemAction.get (PropertiesAction.class),
               };
    }

    public HelpCtx getHelpCtx () {
        return HelpCtx.DEFAULT_HELP;
        // When you have help, change to:
        // return new HelpCtx (__NAME__.class);
    }

    // RECOMMENDED - handle cloning specially (so as not to invoke the overhead of FilterNode):
    /*
    public Node cloneNode () {
      // Try to pass in similar constructor params to what you originally got:
      return new __NAME__ ();
}
    */

    // Create a property sheet:
    /*
    protected Sheet createSheet () {
      Sheet sheet = super.createSheet ();
      // Make sure there is a "Properties" set:
      Sheet.Set props = sheet.get (Sheet.PROPERTIES); // get by name, not display name
      if (props == null) {
        props = Sheet.createPropertiesSet ();
        sheet.put (props);
      }
      props.put (new MyProp (someParams));
}
    */

    // Handle renaming:
    /*
    public boolean canRename () {
      return true;
}
    public void setName (String nue) {
      // Update visible name, fire property changes:
      super.setName (nue);
      // perform additional actions, i.e. rename underlying object
}
    */

    // Handle deleting:
    /*
    public boolean canDestroy () {
      return true;
}
    public void destroy () throws IOException {
      // Actually remove the node itself and fire property changes:
      super.destroy ();
      // perform additional actions, i.e. delete underlying object
}
    */

    // Handle copying and cutting specially:
    /*
    public boolean canCopy () {
      return true;
}
    public boolean canCut () {
      return true;
}
    public Transferable clipboardCopy () {
      // Add to, do not replace, the default node copy flavor:
      ExTransferable et = ExTransferable.create (super.clipboardCopy ());
      et.put (new ExTransferable.Single (DataFlavor.stringFlavor) {
        protected Object getData () {
          return __NAME__.this.getDisplayName ();
        }
      });
      return et;
}
    public Transferable clipboardCut () {
      // Add to, do not replace, the default node cut flavor:
      ExTransferable et = ExTransferable.create (super.clipboardCut ());
      // This is not so useful because this node will not be destroyed afterwards
      // (it is up to the paste type to decide whether to remove the "original",
      // and it is not safe to assume that getData will only be called once):
      et.put (new ExTransferable.Single (DataFlavor.stringFlavor) {
        protected Object getData () {
          return __NAME__.this.getDisplayName ();
        }
      });
      return et;
}
    */

    // Permit user to customize whole node at once (instead of per-property):
    /*
    public boolean hasCustomizer () {
      return true;
}
    public Component getCustomizer () {
      return new MyCustomizingPanel (this);
}
    */

}
