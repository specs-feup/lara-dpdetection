/*
* __NAME__.java
*/ 

package Templates.API_Support.Compiler_API;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.openide.compiler.*;
import org.openide.compiler.Compiler;
import org.openide.execution.NbProcessDescriptor;

public class __Sample_external__CompilerGroup extends ExternalCompilerGroup {

    private String myOpt = null; // will be set after compilers are added

    public void add (Compiler c) throws IllegalArgumentException {
        // Calling super is necessary: that picks up the file list, etc.
        super.add (c);
        if (! (c instanceof __NAME$CompilerGroup$Compiler$MyCompiler__)) throw new IllegalArgumentException ();
        __NAME$CompilerGroup$Compiler$MyCompiler__ comp = (__NAME$CompilerGroup$Compiler$MyCompiler__) c;
        // This will be the same value for all added compilers (if more than one),
        // because of the correct implementation of compilerGroupKey:
        myOpt = comp.getMyOpt ();
    }

    protected Process createProcess (NbProcessDescriptor desc, String[] files) throws IOException {
        return desc.exec (new Format (files, myOpt));
    }

    public static class Format extends ExternalCompilerGroup.Format {

        public static final String TAG_MYOPTIONVAL = "myOpt";

        public Format (String[] files, String myOpt) {
            super (files);
            Map map = getMap ();
            map.put (TAG_MYOPTIONVAL, myOpt);
        }

    }

}
