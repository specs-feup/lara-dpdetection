/*
* __NAME__.java
*/ 

package Templates.API_Support.Actions_API;

import java.awt.event.ActionEvent;
import java.awt.Component;
import javax.swing.*;

import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;
import org.openide.util.actions.Presenter;
import org.openide.util.actions.SystemAction;

/** Action which just holds a few other SystemAction's for grouping purposes.
 *
 * @author  __USER__
 */
public class __Sample_grouping__Action extends SystemAction implements Presenter.Menu, Presenter.Popup, Presenter.Toolbar {

    public void actionPerformed (ActionEvent ev) {
        // do nothing; should not be called
    }

    public String getName () {
        return NbBundle.getBundle (__NAME__.class).getString (__QUOTES__displayNameFor__NAME____QUOTES__);
    }

    protected String iconResource () {
        return __QUOTES____NAME__Icon.gif__QUOTES__;
    }

    public HelpCtx getHelpCtx () {
        return HelpCtx.DEFAULT_HELP;
        // If you will provide context help then use:
        // return new HelpCtx (__NAME__.class);
    }

    /** Perform extra initialization of this action's singleton.
    * PLEASE do not use constructors for this purpose!
    protected void initialize () {
      super.initialize ();
      putProperty ("someProp", value);
}
    */

    /** List of system actions to be displayed within this one's toolbar or submenu. */
    private static final SystemAction[] grouped = new SystemAction[] {
                SystemAction.get (MyFirstAction.class),
                SystemAction.get (MySecondAction.class),
                null,                       // separator
                SystemAction.get (MyThirdAction.class),
            };

    public JMenuItem getMenuPresenter () {
        JMenu menu = new JMenu (getName ());
        menu.setIcon (getIcon ());
        for (int i = 0; i < grouped.length; i++) {
            SystemAction action = grouped[i];
            if (action == null) {
                menu.addSeparator ();
            } else if (action instanceof Presenter.Menu) {
                menu.add (((Presenter.Menu) action).getMenuPresenter ());
            }
        }
        return menu;
    }

    public JMenuItem getPopupPresenter () {
        JMenu menu = new JMenu (getName ());
        // Conventional not to set an icon here.
        for (int i = 0; i < grouped.length; i++) {
            SystemAction action = grouped[i];
            if (action == null) {
                menu.addSeparator ();
            } else if (action instanceof Presenter.Popup) {
                menu.add (((Presenter.Popup) action).getPopupPresenter ());
            }
        }
        return menu;
    }

    public Component getToolbarPresenter () {
        JToolBar toolbar = new JToolBar (/* In JDK 1.3 you may add: getName () */);
        for (int i = 0; i < grouped.length; i++) {
            SystemAction action = grouped[i];
            if (action == null) {
                toolbar.addSeparator ();
            } else if (action instanceof Presenter.Toolbar) {
                toolbar.add (((Presenter.Toolbar) action).getToolbarPresenter ());
            }
        }
        return toolbar;
    }

}
