/*
* __NAME__.java
*/ 

package Templates.API_Support.DataSystems_API;

import org.openide.loaders.*;
import org.openide.nodes.*;
import org.openide.util.NbBundle;

/** A node to represent this object.
 *
 * @author  __USER__
 */
public class __Sample__DataNode extends DataNode {

    public __NAME__ (__NAME$DataNode$DataObject$DataObject__ obj) {
        this (obj, Children.LEAF);
    }

    public __NAME__ (__NAME$DataNode$DataObject$DataObject__ obj, Children ch) {
        super (obj, ch);
        setIconBase (__QUOTES__/__PACKAGE_SLASHES__/__NAME$DataNode$DataIcon$Icon____QUOTES__);
    }

    private __NAME$DataNode$DataObject$DataObject__ get__NAME$DataNode$DataObject$DataObject__ () {
        return (__NAME$DataNode$DataObject$DataObject__) getDataObject ();
    }

    /* Example of adding Executor / Debugger / Arguments to node:
    protected Sheet createSheet () {
      Sheet sheet = super.createSheet ();
      Sheet.Set set = sheet.get (ExecSupport.PROP_EXECUTION);
      if (set == null) {
        set = new Sheet.Set ();
        set.setName (ExecSupport.PROP_EXECUTION);
        set.setDisplayName (NbBundle.getBundle (__NAME__.class).getString (__QUOTES__displayNameFor__NAME__ExecSheet__QUOTES__));
        set.setShortDescription (NbBundle.getBundle (__NAME__.class).getString (__QUOTES__hintFor__NAME__ExecSheet__QUOTES__));
      }
      ((ExecSupport) getCookie (ExecSupport.class)).addProperties (set);
      // Maybe:
      ((CompilerSupport) getCookie (CompilerSupport.class)).addProperties (set);
      sheet.put (set);
      return sheet;
}
    */

    /*
    public SystemAction getDefaultAction () {
      return SystemAction.get (MyFavoriteAction.class);
}
    */

}
