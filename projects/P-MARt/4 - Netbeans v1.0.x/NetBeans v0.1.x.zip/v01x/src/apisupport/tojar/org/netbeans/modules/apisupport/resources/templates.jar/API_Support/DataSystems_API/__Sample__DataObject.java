/*
* __NAME__.java
*/ 

package Templates.API_Support.DataSystems_API;

import org.openide.actions.*;
import org.openide.cookies.*;
import org.openide.filesystems.FileObject;
import org.openide.loaders.*;
import org.openide.nodes.*;
import org.openide.util.HelpCtx;

/** Represents a __NAME$DataObject$$__ object in the Repository.
 *
 * @author  __USER__
 */
public class __Sample__DataObject extends MultiDataObject {

    public __NAME__ (FileObject pf, __NAME$DataObject$DataLoader$MultiFileLoader__ loader) throws DataObjectExistsException {
        super (pf, loader);
        init ();
    }

    private void init () {
        CookieSet cookies = getCookieSet ();
        // Add whatever capabilities you need, e.g.:
        /*
        cookies.add (new ExecSupport (getPrimaryEntry ()));
        cookies.add (new EditorSupport (getPrimaryEntry ()));
        cookies.add (new CompilerSupport.Compile (getPrimaryEntry ()));
        cookies.add (new CompilerSupport.Build (getPrimaryEntry ()));
        cookies.add (new CompilerSupport.Clean (getPrimaryEntry ()));
        cookies.add (new OpenCookie () {
          public void open () {
            // do something...but usually you want to use OpenSupport instead
          }
    });
        */
    }

    public HelpCtx getHelpCtx () {
        return HelpCtx.DEFAULT_HELP;
        // If you add context help, change to:
        // return new HelpCtx (__NAME__.class);
    }

    protected Node createNodeDelegate () {
        return new __NAME$DataObject$DataNode$DataNode__ (this);
    }

}
