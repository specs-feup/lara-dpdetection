/*
* __NAME__.java
*/ 

package Templates.API_Support.Execution_API;

import java.io.IOException;
import java.text.MessageFormat;

import org.openide.TopManager;
import org.openide.execution.*;
import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;
import org.openide.util.io.FoldingIOException;

/** Somehow handles a class present in the Repository by "running" it.
 *
 * @author __USER__
 */
public class __Sample_internal__Executor extends ThreadExecutor {

    // The default value for an unconfigured executor.
    private String myProp = "someDefaultValue";

    public __NAME__ () {
    }

    // You may configure this executor as a JavaBean:
    public String getMyProp () {
        return myProp;
    }

    public synchronized void setMyProp (String nue) {
        String old = myProp;
        myProp = nue;
        firePropertyChange ("myProp", old, nue);
    }

    protected void checkClass (Class clazz) throws IOException {
        try {
            // Just check that there is nothing seriously wrong with the file,
            // e.g. totally inappropriate type of class, etc.
            // ---WARNING---
            // This code will not work when run from the ExecutorTester, if MyInterface is in
            // the Repository--because MyInterface will be loaded from the same classloader as
            // this executor (i.e. the one created by ExecutorTester to test it), while the class
            // being checked here will be loaded from another repository classloader (i.e. one
            // created by this executor). So the cast will fail. To correct the situation, you could
            // e.g. place MyInterface into a library in the NB non-Repository (startup) classpath--
            // make a JAR with it and put that into $NBHOME/lib/ext/. Or, instead of using casts and
            // instanceof, you could use Java Reflection and look up required methods and such by name.
            // Or, use 1.3 Proxy's to delegate from a dummy implementation of the interface (in this
            // classloader) to the real implementation (in the other classloader).
            MyInterface thing = (MyInterface) clazz.newInstance ();
        } catch (ThreadDeath td) {
            throw td;
        } catch (Throwable t) {
            throw new FoldingIOException (t);
        }
    }

    protected void executeClass (Class clazz, String[] args) {
        try {
            // Actually do something with this class, e.g.:
            System.err.println ("Starting here -->"); // shown on OutputWindow
            MyInterface thing = (MyInterface) clazz.newInstance ();
            // Any calls made in clazz to System.err, etc., will go to OutputWindow automatically:
            thing.doSomething (args, getMyProp ());
            System.err.println ("<-- and ending.");
        } catch (ThreadDeath td) {
            throw td;
        } catch (Throwable t) {
            // Will actually go to the OutputWindow automatically:
            t.printStackTrace ();
        }
    }

    /*
    public HelpCtx getHelpCtx () {
      return new HelpCtx (__NAME__.class);
}
    */

}
